// CubeDash Engine - native Android audio: AAudio (low-latency output) + NDK MediaCodec (mp3/ogg/aac/flac/wav decode).
// Music is decoded to RAM and mixed with procedurally generated SFX in one real-time callback. Desktop builds get a silent stub.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
namespace cd {
enum Sfx { SFX_JUMP, SFX_DIE, SFX_COIN, SFX_WIN, SFX_CLICK, SFX_PORTAL, SFX_COUNT };
// Convert interleaved PCM16 of any channel count / rate to 2-channel PCM16 at outRate (linear interpolation).
std::vector<int16_t> toStereo(const int16_t* in, size_t frames, int ch, int rate, int outRate);

class Audio {
 public:
  bool init(); void shutdown(); void update();
  bool load(const std::string& path);            // decodes the whole file (blocks for a second or two)
  void unload(); bool loaded() const;
  void play(float seconds);                      // start music at position
  void stop(); void pause(bool p);
  float position() const; float length() const;  // seconds
  bool playing() const;
  void setMusicVolume(float v); void setSfxVolume(float v);
  void sfx(Sfx s);
  void suspend(bool s);                          // app background/foreground
  struct Impl;
 private:
  Impl* p = nullptr;
};
}  // namespace cd
