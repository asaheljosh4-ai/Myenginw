// CubeDash Engine - platform-independent app layer (screens, editor, game). The platform glue only calls these.
#pragma once
#include <functional>
#include <string>
namespace cd {
struct Platform { std::string dataDir; std::function<void()> pickAudio; std::function<void()> quit; };
struct App;
App* appNew(const Platform& p);
void appDel(App* a);
void appGfxInit(App* a, int w, int h);        // call once the GL context is current (and again after context loss)
void appGfxLost(App* a);
void appResize(App* a, int w, int h);
void appTouch(App* a, int id, int action /*0 down 1 move 2 up*/, float x, float y);
bool appBack(App* a);                          // returns false if the app should close
void appFrame(App* a, float dt);               // update + render (GL context must be current)
void appForeground(App* a, bool fg);
void appMusicImported(App* a, const std::string& path);   // may be called from any thread
}  // namespace cd
