cmake_minimum_required(VERSION 3.22)
project(cubedash LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(cubedash SHARED android_main.cpp App.cpp Gfx.cpp Audio.cpp)
# android_native_app_glue ships with the NDK
add_library(native_app_glue STATIC ${ANDROID_NDK}/sources/android/native_app_glue/android_native_app_glue.c)
target_include_directories(cubedash PRIVATE ${ANDROID_NDK}/sources/android/native_app_glue)
target_compile_options(cubedash PRIVATE -O2 -Wall)
target_link_libraries(cubedash native_app_glue android log EGL GLESv3 aaudio mediandk)
set_target_properties(cubedash PROPERTIES LINK_FLAGS "-u ANativeActivity_onCreate")
