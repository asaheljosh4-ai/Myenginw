// CubeDash Engine - Android NativeActivity glue: EGL/GLES3 context, input, lifecycle, JNI music picker.
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <jni.h>
#include <chrono>
#include <string>
#include "App.h"
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "CubeDash", __VA_ARGS__)
using namespace cd;

static App* gApp = nullptr;   // set once the engine is created; JNI callback may arrive from the UI thread

struct Egl {
  EGLDisplay d = EGL_NO_DISPLAY; EGLSurface s = EGL_NO_SURFACE; EGLContext c = EGL_NO_CONTEXT; EGLConfig cfg = nullptr; int w = 0, h = 0;
  bool initDisplay() {
    d = eglGetDisplay(EGL_DEFAULT_DISPLAY); if (!eglInitialize(d, nullptr, nullptr)) return false;
    const EGLint ca[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 0, EGL_NONE};
    EGLint n = 0; if (!eglChooseConfig(d, ca, &cfg, 1, &n) || n < 1) return false;
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE}; c = eglCreateContext(d, cfg, EGL_NO_CONTEXT, xa); return c != EGL_NO_CONTEXT;
  }
  bool attach(ANativeWindow* win) {
    EGLint fmt; eglGetConfigAttrib(d, cfg, EGL_NATIVE_VISUAL_ID, &fmt); ANativeWindow_setBuffersGeometry(win, 0, 0, fmt);
    s = eglCreateWindowSurface(d, cfg, win, nullptr); if (s == EGL_NO_SURFACE || !eglMakeCurrent(d, s, s, c)) return false;
    eglQuerySurface(d, s, EGL_WIDTH, &w); eglQuerySurface(d, s, EGL_HEIGHT, &h); eglSwapInterval(d, 1); return true;
  }
  void detach() { if (d != EGL_NO_DISPLAY) { eglMakeCurrent(d, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT); if (s != EGL_NO_SURFACE) eglDestroySurface(d, s); s = EGL_NO_SURFACE; } }
  void destroy() { detach(); if (c != EGL_NO_CONTEXT) eglDestroyContext(d, c); if (d != EGL_NO_DISPLAY) eglTerminate(d); c = EGL_NO_CONTEXT; d = EGL_NO_DISPLAY; }
};

struct State { android_app* app; Egl egl; bool hasWin = false, running = true, fg = false; JNIEnv* env = nullptr; };

static int32_t onInput(android_app* app, AInputEvent* e) {
  State* st = (State*)app->userData; if (!gApp || AInputEvent_getType(e) != AINPUT_EVENT_TYPE_MOTION) {
    if (AInputEvent_getType(e) == AINPUT_EVENT_TYPE_KEY && AKeyEvent_getKeyCode(e) == AKEYCODE_BACK && AKeyEvent_getAction(e) == AKEY_EVENT_ACTION_UP) { if (gApp && !appBack(gApp)) { st->running = false; ANativeActivity_finish(app->activity); } return 1; }
    return 0; }
  int32_t a = AMotionEvent_getAction(e), act = a & AMOTION_EVENT_ACTION_MASK; int idx = (a & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
  switch (act) {
    case AMOTION_EVENT_ACTION_DOWN: case AMOTION_EVENT_ACTION_POINTER_DOWN: appTouch(gApp, AMotionEvent_getPointerId(e, idx), 0, AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx)); break;
    case AMOTION_EVENT_ACTION_UP: case AMOTION_EVENT_ACTION_POINTER_UP: appTouch(gApp, AMotionEvent_getPointerId(e, idx), 2, AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx)); break;
    case AMOTION_EVENT_ACTION_CANCEL: for (size_t i = 0; i < AMotionEvent_getPointerCount(e); i++) appTouch(gApp, AMotionEvent_getPointerId(e, i), 2, AMotionEvent_getX(e, i), AMotionEvent_getY(e, i)); break;
    case AMOTION_EVENT_ACTION_MOVE: for (size_t i = 0; i < AMotionEvent_getPointerCount(e); i++) appTouch(gApp, AMotionEvent_getPointerId(e, i), 1, AMotionEvent_getX(e, i), AMotionEvent_getY(e, i)); break;
  }
  return 1;
}
static void onCmd(android_app* app, int32_t cmd) {
  State* st = (State*)app->userData;
  switch (cmd) {
    case APP_CMD_INIT_WINDOW:
      if (app->window) {
        if (st->egl.c == EGL_NO_CONTEXT && !st->egl.initDisplay()) { LOG("EGL init failed"); st->running = false; return; }
        if (!st->egl.attach(app->window)) { LOG("EGL attach failed"); st->running = false; return; }
        st->hasWin = true; if (gApp) appGfxInit(gApp, st->egl.w, st->egl.h);
      } break;
    case APP_CMD_WINDOW_RESIZED: case APP_CMD_CONFIG_CHANGED: if (st->hasWin && gApp) { eglQuerySurface(st->egl.d, st->egl.s, EGL_WIDTH, &st->egl.w); eglQuerySurface(st->egl.d, st->egl.s, EGL_HEIGHT, &st->egl.h); appResize(gApp, st->egl.w, st->egl.h); } break;
    case APP_CMD_TERM_WINDOW: st->hasWin = false; if (gApp) appGfxLost(gApp); st->egl.detach(); break;
    case APP_CMD_GAINED_FOCUS: case APP_CMD_RESUME: st->fg = true; if (gApp) appForeground(gApp, true); break;
    case APP_CMD_LOST_FOCUS: case APP_CMD_PAUSE: st->fg = false; if (gApp) appForeground(gApp, false); break;
    case APP_CMD_DESTROY: st->running = false; break;
  }
}

// ---- JNI: Java -> native (called on the UI thread after the user picked + we copied an audio file) ----
extern "C" JNIEXPORT void JNICALL Java_com_cubedash_engine_MainActivity_nativeMusicImported(JNIEnv* env, jobject, jstring path) {
  if (!gApp || !path) return; const char* c = env->GetStringUTFChars(path, nullptr); appMusicImported(gApp, c); env->ReleaseStringUTFChars(path, c);
}

void android_main(android_app* app) {
  State st; st.app = app; app->userData = &st; app->onAppCmd = onCmd; app->onInputEvent = onInput;
  JavaVM* vm = app->activity->vm; vm->AttachCurrentThread(&st.env, nullptr); jobject activity = app->activity->clazz;
  Platform plat; plat.dataDir = app->activity->internalDataPath ? app->activity->internalDataPath : "/data/local/tmp";
  plat.pickAudio = [&]() {   // call MainActivity.pickAudio() on the UI thread (it opens the system file picker)
    jclass cls = st.env->GetObjectClass(activity); jmethodID m = st.env->GetMethodID(cls, "pickAudio", "()V"); if (m) st.env->CallVoidMethod(activity, m); st.env->DeleteLocalRef(cls); };
  plat.quit = [&]() { st.running = false; ANativeActivity_finish(app->activity); };
  gApp = appNew(plat); if (st.hasWin) appGfxInit(gApp, st.egl.w, st.egl.h);
  auto last = std::chrono::steady_clock::now();
  while (st.running) {
    int ev; android_poll_source* src;
    while (ALooper_pollOnce(st.hasWin && st.fg ? 0 : 250, nullptr, &ev, (void**)&src) >= 0) { if (src) src->process(app, src); if (app->destroyRequested) st.running = false; }
    if (!st.running) break;
    if (st.hasWin && st.fg) {
      auto now = std::chrono::steady_clock::now(); float dt = std::chrono::duration<float>(now - last).count(); last = now;
      appFrame(gApp, dt); eglSwapBuffers(st.egl.d, st.egl.s);
    } else last = std::chrono::steady_clock::now();
  }
  App* a = gApp; gApp = nullptr; appDel(a); st.egl.destroy(); vm->DetachCurrentThread();
}
