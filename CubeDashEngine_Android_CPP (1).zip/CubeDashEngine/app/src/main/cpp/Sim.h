// CubeDash Engine - deterministic fixed-step simulation (cube, ship, wave, ball)
#pragma once
#include "Level.h"
#include <cmath>
#include <vector>
#include <unordered_set>
namespace cd {
constexpr float SPD[5] = {8.372f, 10.386f, 12.914f, 15.6f, 19.2f};
constexpr float DT = 1.f / 240.f, JUMP = 11.180032f * 60 / 30, GR = 0.958199f * 3600 / 30, GRB = GR * .75f;
constexpr float PADV = 32, PINKP = 20, PINKO = 15.5f, TV = -30, SUP = 50, SDN = 40, SMAX = 9, SMIN = -10, CEIL = 10;
constexpr float E = 1e-6f, FG_TOP = .3f, FG_CEIL = .22f, COIN_R2 = 1.21f;
enum Ev : unsigned { EV_JUMP = 1, EV_DIE = 2, EV_COIN = 4, EV_PAD = 8, EV_ORB = 16, EV_PORTAL = 32, EV_WIN = 64 };
struct Hit { int x, y; float top; };
struct Player { float x = 0, y = 0, vy = 0, rot = 0, px = 0, py = 0, pr = 0, cy = 0; int gd = 1; char m = 'c'; bool og = true, air = false, dead = false; };
struct Checkpoint { float x, y, vy, rot; int gd; char m; std::vector<Key> got; };

struct Sim {
  const Level* L = nullptr; Player P; bool held = false, won = false, practice = false, fromStart = false;
  float buf = 0, endX = 40, simT = 0, lastCp = 0; int tot = 0, sp = 1;
  unsigned ev = 0; float evx = 0, evy = 0;
  std::unordered_set<Key> got; std::vector<Checkpoint> cps;

  void begin(const Level* lv, bool prac) { L = lv; practice = prac; sp = lv->speed; endX = (float)lv->maxX() + 10; tot = lv->coins(); simT = 0; cps.clear(); reset(nullptr); }
  void press() { held = true; buf = .12f; }
  void release() { held = false; }
  float timeAt(float x) const { return x / SPD[sp]; }
  int gotCoins() const { int n = 0; for (auto k : got) n += L->get(KX(k), KY(k)) == 'c'; return n; }

  void reset(const Checkpoint* c) {
    P = Player(); got.clear(); won = false; buf = 0; ev = 0; lastCp = simT;
    if (c) { P.x = c->x; P.y = c->y; P.vy = c->vy; P.rot = c->rot; P.gd = c->gd; P.m = c->m; for (auto k : c->got) got.insert(k); }
    else {
      cps.clear(); P.x = (float)L->startX; P.y = (float)L->startY; fromStart = L->startX > 0 || L->startY > 0; int best = -1;
      for (auto& p : L->t) if (isPortal(p.second) && KX(p.first) <= L->startX && KX(p.first) > best) { best = KX(p.first); P.m = (char)std::tolower(p.second) == 'c' ? 'c' : p.second == 'S' ? 's' : p.second == 'W' ? 'w' : 'b'; }
    }
    P.px = P.x; P.py = P.y; P.pr = P.rot; P.og = true;
  }
  void respawn() { if (practice && !cps.empty()) { auto c = cps.back(); if (cps.size() > 1 && P.x - c.x < 1.2f) { cps.pop_back(); c = cps.back(); } reset(&c); } else reset(nullptr); }

  bool solid(float x, float y, float w, float h, Hit& o) const {
    for (int cx = (int)std::floor(x + E); cx <= (int)std::floor(x + w - E); cx++)
      for (int cy = (int)std::floor(y + E); cy <= (int)std::floor(y + h - E); cy++) {
        float sh = solidH(L->get(cx, cy)); if (sh > 0 && y < cy + sh - E) { o = {cx, cy, cy + sh}; return true; }
      }
    return false;
  }
  bool below() const {
    for (int cx = (int)std::floor(P.x + E); cx <= (int)std::floor(P.x + 1 - E); cx++)
      for (int cy = (int)std::floor(P.y) - 1; cy <= (int)std::floor(P.y + E); cy++) { float h = solidH(L->get(cx, cy)); if (h > 0 && std::fabs(cy + h - P.y) < E) return true; }
    return false;
  }
  bool above() const {
    int cy = (int)std::lround(P.y + 1);
    for (int cx = (int)std::floor(P.x + E); cx <= (int)std::floor(P.x + 1 - E); cx++) if (solidH(L->get(cx, cy)) > 0 && std::fabs(cy - (P.y + 1)) < E) return true;
    return false;
  }
  static bool ov(float x0, float y0, float x1, float y1, float fx, float fy, float fw, float fh) { return fx < x1 && fx + fw > x0 && fy < y1 && fy + fh > y0; }
  static float cl(float v, float a, float b) { return std::max(a, std::min(b, v)); }

  bool hazards() {
    float a = P.x + .3f, b = P.y + .3f, z = .4f;
    for (int cx = (int)std::floor(P.x) - 2; cx <= (int)std::floor(P.x) + 2; cx++)
      for (int cy = (int)std::floor(P.y) - 2; cy <= (int)std::floor(P.y) + 3; cy++) {
        char t = L->get(cx, cy); if (!t || solidH(t) > 0) continue; Key k = K(cx, cy);
        switch (t) {
          case 's': if (ov(cx + .42f, cy + .1f, cx + .58f, cy + .5f, a, b, z, z)) return true; break;
          case 'n': if (ov(cx + .4f, cy + .05f, cx + .6f, cy + .28f, a, b, z, z)) return true; break;
          case 'd': if (ov(cx + .42f, cy + .5f, cx + .58f, cy + .9f, a, b, z, z)) return true; break;
          case 'w': { float nx = cl(cx + .5f, a, a + z), ny = cl(cy + .5f, b, b + z); if ((nx - cx - .5f) * (nx - cx - .5f) + (ny - cy - .5f) * (ny - cy - .5f) < .11f) return true; break; }
          case 'p': case 'k': if (!got.count(k) && ov(cx, cy, cx + 1, cy + .3f, P.x, P.y, 1, 1)) {
            float v = t == 'p' ? PADV : PINKP; P.vy = P.m == 'b' ? -P.gd * v * .6f : v; got.insert(k); ev |= EV_PAD; evx = cx + .5f; evy = cy + .2f; } break;
          case 'o': case 'q': if (buf > 0 && !got.count(k) && ov(cx - .3f, cy - .3f, cx + 1.3f, cy + 1.3f, P.x, P.y, 1, 1)) {
            if (P.m == 'b') { P.gd = -P.gd; P.vy = 0; } else P.vy = t == 'o' ? JUMP : PINKO;
            buf = 0; got.insert(k); ev |= EV_ORB; evx = cx + .5f; evy = cy + .5f; } break;
          case 'S': case 'C': case 'W': case 'B': if (ov(cx, cy - 1, cx + 1, cy + 2, P.x, P.y, 1, 1)) {
            char m = t == 'S' ? 's' : t == 'C' ? 'c' : t == 'W' ? 'w' : 'b';
            if (P.m != m) { P.m = m; P.gd = 1; if (m == 's') P.vy = cl(P.vy, -3, 3); ev |= EV_PORTAL; evx = cx + .5f; evy = cy + .5f; } } break;
          case 'c': if (!got.count(k) && (P.x + .5f - cx - .5f) * (P.x + .5f - cx - .5f) + (P.y + .5f - cy - .5f) * (P.y + .5f - cy - .5f) < COIN_R2) { got.insert(k); ev |= EV_COIN; evx = cx + .5f; evy = cy + .5f; } break;
        }
      }
    return false;
  }
  void die() { if (P.dead) return; P.dead = true; ev |= EV_DIE; evx = P.x + .5f; evy = P.y + .5f; }

  void step() {
    P.px = P.x; P.py = P.y; P.pr = P.rot; simT += DT; buf = std::max(0.f, buf - DT);
    const float V = SPD[sp]; Hit b;
    if (P.m == 'w') { stepWave(V); return; }
    P.og = P.gd == 1 ? (P.y <= E || below()) : (P.y >= CEIL - E || above());
    P.cy = P.og ? .06f : P.cy - DT;
    if (P.m == 's') P.vy = cl(P.vy + (held ? SUP : -SDN) * DT, SMIN, SMAX);
    else if (P.m == 'b') {
      if (buf > 0 && P.og) { P.gd = -P.gd; P.vy = 0; P.og = false; buf = 0; ev |= EV_JUMP; evx = P.x + .5f; evy = P.y + .5f; }
      P.vy = cl(P.vy - P.gd * GRB * DT, TV, -TV);
    } else {
      if ((held && P.og) || (buf > 0 && P.cy > 0)) { P.vy = JUMP; P.og = false; P.cy = 0; buf = 0; ev |= EV_JUMP; evx = P.x + .5f; evy = P.y + .05f; }
      P.vy = std::max(TV, P.vy - GR * DT);
    }
    P.x += V * DT;
    if (solid(P.x, P.y, 1, 1, b)) {
      if (P.gd == 1 && P.vy <= 0 && b.top - P.y <= FG_TOP) { P.y = b.top; P.vy = 0; P.og = true; }
      else if (P.gd == -1 && P.m == 'b' && P.y + 1 - b.y <= FG_TOP && b.y >= P.y + .5f) { P.y = b.y - 1; P.vy = 0; P.og = true; }
      else return die();
    }
    float py = P.y; P.y += P.vy * DT;
    if (P.y <= 0) { P.y = 0; P.vy = std::max(0.f, P.vy); P.og = P.gd == 1; }
    else if (P.m != 'c' && P.y > CEIL) { P.y = CEIL; P.vy = std::min(0.f, P.vy); P.og = P.gd == -1; }
    if (solid(P.x, P.y, 1, 1, b)) {
      if (P.vy <= 0 && py >= b.top - 1e-4f) { P.y = b.top; P.vy = 0; P.og = P.gd == 1; }
      else if (P.vy > 0 && (P.m == 's' || (P.m == 'b' && P.gd == -1) || P.y + 1 - b.y <= FG_CEIL)) { P.y = b.y - 1; P.vy = 0; P.og = P.gd == -1; }
      else return die();
    }
    if (hazards()) return die();
    P.air = !P.og;
    if (P.m == 's') P.rot += (-std::atan2(P.vy, V) * 57.3f - P.rot) * .15f;
    else if (P.m == 'b') P.rot += P.gd * V * DT * 114.6f;
    else if (P.og) P.rot += (std::round(P.rot / 90) * 90 - P.rot) * .12f; else P.rot += 463 * DT;
    finishStep();
  }
  void stepWave(float V) {
    Hit b; P.vy = held ? V : -V; P.og = false; P.x += V * DT;
    if (solid(P.x + .3f, P.y + .3f, .4f, .4f, b)) return die();
    float py = P.y; P.y += P.vy * DT;
    P.y = std::max(-.3f, std::min(CEIL + .3f, P.y));
    if (solid(P.x + .3f, P.y + .3f, .4f, .4f, b)) P.y = py;   // slide along block surfaces
    if (hazards()) return die();
    P.rot = std::atan2(P.y - py, V * DT) * 57.3f; finishStep();
  }
  void finishStep() {
    if (practice && simT - lastCp > 1.2f && (P.og || P.m == 's' || P.m == 'w')) { lastCp = simT; cps.push_back({P.x, P.y, P.vy, P.rot, P.gd, P.m, std::vector<Key>(got.begin(), got.end())}); if (cps.size() > 40) cps.erase(cps.begin()); }
    if (P.x > endX) { won = true; ev |= EV_WIN; evx = P.x; evy = P.y; }
  }
};
}  // namespace cd
