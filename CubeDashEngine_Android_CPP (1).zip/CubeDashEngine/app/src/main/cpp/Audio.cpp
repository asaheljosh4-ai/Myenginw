#include "Audio.h"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <mutex>
#if defined(__ANDROID__)
#include <aaudio/AAudio.h>
#include <android/log.h>
#include <media/NdkMediaCodec.h>
#include <media/NdkMediaExtractor.h>
#include <media/NdkMediaFormat.h>
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "CubeDash", __VA_ARGS__)
#endif
namespace cd {
std::vector<int16_t> toStereo(const int16_t* in, size_t frames, int ch, int rate, int outRate) {
  std::vector<int16_t> out; if (!in || !frames || ch < 1 || rate < 1 || outRate < 1) return out;
  size_t n = (size_t)((double)frames * outRate / rate); out.resize(n * 2);
  for (size_t i = 0; i < n; i++) {
    double s = (double)i * rate / outRate; size_t i0 = std::min((size_t)s, frames - 1), i1 = std::min(i0 + 1, frames - 1); float f = (float)(s - (double)i0);
    for (int c = 0; c < 2; c++) { int cc = std::min(c, ch - 1); float a = in[i0 * ch + cc], b = in[i1 * ch + cc]; out[i * 2 + c] = (int16_t)(a + (b - a) * f); }
  }
  return out;
}
static std::vector<int16_t> synth(int kind) {   // tiny procedural sound effects, mono 44.1k
  const int sr = 44100; float dur = kind == 1 ? .45f : kind == 2 ? .25f : kind == 3 ? .8f : kind == 5 ? .3f : .12f; int n = (int)(dur * sr); std::vector<int16_t> o(n); float ph = 0;
  for (int i = 0; i < n; i++) {
    float t = (float)i / sr, k = t / dur, env = std::pow(1 - k, 2.f), f, s;
    switch (kind) {
      case 1: f = 220 - 160 * k; ph += f / sr; s = (std::sin(ph * 6.2832f) > 0 ? .5f : -.5f) + ((rand() & 1023) / 1023.f - .5f) * .8f; break;
      case 2: f = k < .4f ? 988 : 1319; ph += f / sr; s = std::sin(ph * 6.2832f); env = k < .4f ? 1 - k : std::pow(1 - k, 2.f); break;
      case 3: { static const float nt[] = {523, 659, 784, 1046}; f = nt[std::min(3, (int)(k * 4))]; ph += f / sr; s = std::sin(ph * 6.2832f) * .7f; env = 1 - k; break; }
      case 5: f = 300 + 700 * k; ph += f / sr; s = std::sin(ph * 6.2832f); break;
      case 4: f = 660; ph += f / sr; s = std::sin(ph * 6.2832f) * .6f; break;
      default: f = 500 + 500 * k; ph += f / sr; s = std::sin(ph * 6.2832f) * .5f; break;
    }
    o[i] = (int16_t)(std::max(-1.f, std::min(1.f, s * env * .6f)) * 32767);
  }
  return o;
}

#if defined(__ANDROID__)
struct Voice { std::atomic<bool> active{false}; const int16_t* data = nullptr; size_t frames = 0, pos = 0; };
struct Audio::Impl {
  AAudioStream* stream = nullptr; int rate = 44100;
  std::mutex m; std::vector<int16_t> music;              // stereo interleaved at `rate`; guarded by m (callback uses try_lock)
  std::atomic<int64_t> pos{0}; std::atomic<bool> playing{false}, paused{false}, restart{false}, hasMusic{false};
  std::atomic<float> mv{1.f}, sv{1.f}; std::vector<int16_t> fx[SFX_COUNT]; Voice voices[16]; std::atomic<unsigned> nextVoice{0}; bool suspended = false;
  bool open(); void closeStream();
};
static inline int16_t sat(int v) { return (int16_t)std::max(-32768, std::min(32767, v)); }
static aaudio_data_callback_result_t dataCb(AAudioStream*, void* ud, void* audio, int32_t n) {
  Audio::Impl* p = (Audio::Impl*)ud; int16_t* o = (int16_t*)audio; std::memset(o, 0, (size_t)n * 4); float mv = p->mv, sv = p->sv;
  { std::unique_lock<std::mutex> lk(p->m, std::try_to_lock);
    if (lk.owns_lock() && p->playing && !p->paused && !p->music.empty()) {
      int64_t total = (int64_t)p->music.size() / 2, pos = std::max<int64_t>(0, p->pos), k = std::min<int64_t>(n, total - pos);
      for (int64_t i = 0; i < k; i++) { o[i * 2] = sat((int)(p->music[(pos + i) * 2] * mv)); o[i * 2 + 1] = sat((int)(p->music[(pos + i) * 2 + 1] * mv)); }
      p->pos = pos + std::max<int64_t>(0, k); if (pos + k >= total) p->playing = false; } }
  for (auto& v : p->voices) if (v.active.load(std::memory_order_acquire)) {
    int i = 0; for (; i < n && v.pos < v.frames; i++, v.pos++) { o[i * 2] = sat(o[i * 2] + (int)(v.data[v.pos * 2] * sv)); o[i * 2 + 1] = sat(o[i * 2 + 1] + (int)(v.data[v.pos * 2 + 1] * sv)); }
    if (v.pos >= v.frames) v.active.store(false, std::memory_order_release); }
  return AAUDIO_CALLBACK_RESULT_CONTINUE;
}
static void errCb(AAudioStream*, void* ud, aaudio_result_t err) { if (err == AAUDIO_ERROR_DISCONNECTED) ((Audio::Impl*)ud)->restart = true; }
bool Audio::Impl::open() {
  AAudioStreamBuilder* b = nullptr; if (AAudio_createStreamBuilder(&b) != AAUDIO_OK) return false;
  AAudioStreamBuilder_setDirection(b, AAUDIO_DIRECTION_OUTPUT); AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY); AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
  AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_I16); AAudioStreamBuilder_setChannelCount(b, 2); AAudioStreamBuilder_setSampleRate(b, 44100);
  AAudioStreamBuilder_setDataCallback(b, dataCb, this); AAudioStreamBuilder_setErrorCallback(b, errCb, this);
  aaudio_result_t r = AAudioStreamBuilder_openStream(b, &stream); AAudioStreamBuilder_delete(b); if (r != AAUDIO_OK) { stream = nullptr; LOGE("AAudio open failed %d", (int)r); return false; }
  rate = AAudioStream_getSampleRate(stream); AAudioStream_setBufferSizeInFrames(stream, AAudioStream_getFramesPerBurst(stream) * 2);
  return AAudioStream_requestStart(stream) == AAUDIO_OK;
}
void Audio::Impl::closeStream() { if (stream) { AAudioStream_requestStop(stream); AAudioStream_close(stream); stream = nullptr; } }

bool Audio::init() {
  p = new Impl(); if (!p->open()) return false;
  for (int i = 0; i < SFX_COUNT; i++) { auto m = synth(i == SFX_JUMP ? 0 : i == SFX_DIE ? 1 : i == SFX_COIN ? 2 : i == SFX_WIN ? 3 : i == SFX_CLICK ? 4 : 5); p->fx[i] = toStereo(m.data(), m.size(), 1, 44100, p->rate); }
  return true;
}
void Audio::shutdown() { if (!p) return; p->closeStream(); delete p; p = nullptr; }
void Audio::update() { if (p && p->restart.exchange(false)) { p->closeStream(); if (!p->open()) LOGE("AAudio reopen failed"); } }

static bool decodeFile(const std::string& path, std::vector<int16_t>& pcm, int& ch, int& rate) {
  AMediaExtractor* ex = AMediaExtractor_new(); if (AMediaExtractor_setDataSource(ex, path.c_str()) != AMEDIA_OK) { AMediaExtractor_delete(ex); return false; }
  AMediaCodec* codec = nullptr; ch = 2; rate = 44100;
  for (size_t i = 0, nt = AMediaExtractor_getTrackCount(ex); i < nt && !codec; i++) {
    AMediaFormat* f = AMediaExtractor_getTrackFormat(ex, i); const char* mime = nullptr; AMediaFormat_getString(f, AMEDIAFORMAT_KEY_MIME, &mime);
    if (mime && !std::strncmp(mime, "audio/", 6)) { AMediaExtractor_selectTrack(ex, i); codec = AMediaCodec_createDecoderByType(mime);
      if (codec) { AMediaCodec_configure(codec, f, nullptr, nullptr, 0); AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_SAMPLE_RATE, &rate); AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_CHANNEL_COUNT, &ch); } }
    AMediaFormat_delete(f);
  }
  if (!codec) { AMediaExtractor_delete(ex); return false; }
  AMediaCodec_start(codec); bool inEos = false, outEos = false; int idle = 0; const size_t cap = (size_t)44100 * 2 * 60 * 15;   // 15 minutes max
  while (!outEos && pcm.size() < cap && idle < 800) {
    if (!inEos) { ssize_t ii = AMediaCodec_dequeueInputBuffer(codec, 2000);
      if (ii >= 0) { size_t sz = 0; uint8_t* b = AMediaCodec_getInputBuffer(codec, (size_t)ii, &sz); ssize_t n = AMediaExtractor_readSampleData(ex, b, sz);
        if (n < 0) { AMediaCodec_queueInputBuffer(codec, (size_t)ii, 0, 0, 0, AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM); inEos = true; }
        else { AMediaCodec_queueInputBuffer(codec, (size_t)ii, 0, (size_t)n, (uint64_t)AMediaExtractor_getSampleTime(ex), 0); AMediaExtractor_advance(ex); } } }
    AMediaCodecBufferInfo info; ssize_t oi = AMediaCodec_dequeueOutputBuffer(codec, &info, 2000);
    if (oi >= 0) { idle = 0; size_t sz = 0; uint8_t* b = AMediaCodec_getOutputBuffer(codec, (size_t)oi, &sz);
      if (b && info.size > 0) { const int16_t* s = (const int16_t*)(b + info.offset); pcm.insert(pcm.end(), s, s + info.size / 2); }
      if (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) outEos = true; AMediaCodec_releaseOutputBuffer(codec, (size_t)oi, false); }
    else if (oi == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) { AMediaFormat* f = AMediaCodec_getOutputFormat(codec); AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_SAMPLE_RATE, &rate); AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_CHANNEL_COUNT, &ch); AMediaFormat_delete(f); }
    else idle++;
  }
  AMediaCodec_stop(codec); AMediaCodec_delete(codec); AMediaExtractor_delete(ex); return !pcm.empty() && ch > 0;
}
bool Audio::load(const std::string& path) {
  if (!p) return false; unload(); std::vector<int16_t> raw; int ch = 2, rate = 44100;
  if (!decodeFile(path, raw, ch, rate)) { LOGE("cannot decode %s", path.c_str()); return false; }
  std::vector<int16_t> st = toStereo(raw.data(), raw.size() / (size_t)ch, ch, rate, p->rate); raw.clear(); raw.shrink_to_fit(); if (st.empty()) return false;
  { std::lock_guard<std::mutex> l(p->m); p->music.swap(st); p->pos = 0; } p->hasMusic = true; return true;
}
void Audio::unload() { if (!p) return; p->playing = false; std::vector<int16_t> old; { std::lock_guard<std::mutex> l(p->m); old.swap(p->music); } p->hasMusic = false; p->pos = 0; }
bool Audio::loaded() const { return p && p->hasMusic; }
void Audio::play(float s) { if (!p || !p->hasMusic) return; p->pos = (int64_t)(std::max(0.f, s) * p->rate); p->paused = false; p->playing = true; }
void Audio::stop() { if (p) p->playing = false; }
void Audio::pause(bool b) { if (p) p->paused = b; }
float Audio::position() const { return p ? (float)p->pos / p->rate : 0.f; }
float Audio::length() const { if (!p || !p->hasMusic) return 0; std::lock_guard<std::mutex> l(p->m); return (float)(p->music.size() / 2) / p->rate; }
bool Audio::playing() const { return p && p->playing && !p->paused; }
void Audio::setMusicVolume(float v) { if (p) p->mv = v; }
void Audio::setSfxVolume(float v) { if (p) p->sv = v; }
void Audio::sfx(Sfx s) {
  if (!p || p->fx[s].empty()) return; for (int t = 0; t < 16; t++) { Voice& v = p->voices[p->nextVoice++ % 16]; if (v.active.load(std::memory_order_acquire)) continue;
    v.data = p->fx[s].data(); v.frames = p->fx[s].size() / 2; v.pos = 0; v.active.store(true, std::memory_order_release); return; }
}
void Audio::suspend(bool s) { if (!p || !p->stream || s == p->suspended) return; p->suspended = s; if (s) AAudioStream_requestPause(p->stream); else AAudioStream_requestStart(p->stream); }
#else   // desktop / unsupported: silent stub so the engine still builds for tests
struct Audio::Impl {};
bool Audio::init() { return false; } void Audio::shutdown() {} void Audio::update() {} bool Audio::load(const std::string&) { return false; } void Audio::unload() {} bool Audio::loaded() const { return false; }
void Audio::play(float) {} void Audio::stop() {} void Audio::pause(bool) {} float Audio::position() const { return 0; } float Audio::length() const { return 0; } bool Audio::playing() const { return false; }
void Audio::setMusicVolume(float) {} void Audio::setSfxVolume(float) {} void Audio::sfx(Sfx) {} void Audio::suspend(bool) {}
#endif
}  // namespace cd
