#include "Gfx.h"
#include <GLES3/gl3.h>
#include <cmath>
#include <cstring>
#include <cctype>
namespace cd {
uint32_t hsl(float h, float s, float l, float a) {
  h = std::fmod(std::fmod(h, 360.f) + 360.f, 360.f); float c = (1 - std::fabs(2 * l - 1)) * s, x = c * (1 - std::fabs(std::fmod(h / 60, 2.f) - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  return RGBA((int)((r + m) * 255), (int)((g + m) * 255), (int)((b + m) * 255), (int)(a * 255));
}
uint32_t withAlpha(uint32_t c, float a) { return (c & 0x00ffffffu) | ((uint32_t)(std::max(0.f, std::min(1.f, a)) * (c >> 24)) << 24); }

static const uint8_t F[64][5] = {  // ASCII 32..95, column-major, bit0 = top row
 {0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,8,0x64,0x62},{0x36,0x49,0x55,0x22,0x50},{0,5,3,0,0},
 {0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},{0x14,8,0x3E,8,0x14},{8,8,0x3E,8,8},{0,0x50,0x30,0,0},{8,8,8,8,8},{0,0x60,0x60,0,0},{0x20,0x10,8,4,2},
 {0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{1,0x71,9,5,3},
 {0x36,0x49,0x49,0x49,0x36},{6,0x49,0x49,0x29,0x1E},{0,0x36,0x36,0,0},{0,0x56,0x36,0,0},{8,0x14,0x22,0x41,0},{0x14,0x14,0x14,0x14,0x14},{0,0x41,0x22,0x14,8},{2,1,0x51,9,6},
 {0x32,0x49,0x79,0x41,0x3E},{0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},{0x3E,0x41,0x49,0x49,0x7A},
 {0x7F,8,8,8,0x7F},{0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},{0x7F,2,0x0C,2,0x7F},{0x7F,4,8,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
 {0x7F,9,9,9,6},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},{0x46,0x49,0x49,0x49,0x31},{1,1,0x7F,1,1},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},
 {0x63,0x14,8,0x14,0x63},{7,8,0x70,8,7},{0x61,0x51,0x49,0x45,0x43},{0,0x7F,0x41,0x41,0},{2,4,8,0x10,0x20},{0,0x41,0x41,0x7F,0},{4,2,1,2,4},{0x40,0x40,0x40,0x40,0x40}};

static const char* VS = "#version 300 es\nlayout(location=0) in vec2 p; layout(location=1) in vec4 c; uniform vec2 res; out vec4 vc;\nvoid main(){ vc=c; gl_Position=vec4(p.x/res.x*2.0-1.0, 1.0-p.y/res.y*2.0, 0.0, 1.0); }";
static const char* FS = "#version 300 es\nprecision mediump float; in vec4 vc; out vec4 o; void main(){ o=vc; }";
static unsigned mk(GLenum t, const char* s) { unsigned h = glCreateShader(t); glShaderSource(h, 1, &s, nullptr); glCompileShader(h); return h; }

bool Gfx::init() {
  if (prog_) return true;   // context survives window changes
  prog_ = glCreateProgram(); unsigned a = mk(GL_VERTEX_SHADER, VS), b = mk(GL_FRAGMENT_SHADER, FS);
  glAttachShader(prog_, a); glAttachShader(prog_, b); glLinkProgram(prog_); glDeleteShader(a); glDeleteShader(b);
  int ok = 0; glGetProgramiv(prog_, GL_LINK_STATUS, &ok); if (!ok) return false;
  uRes_ = glGetUniformLocation(prog_, "res");
  glGenVertexArrays(1, &vao_); glGenBuffers(1, &vbo_); glBindVertexArray(vao_); glBindBuffer(GL_ARRAY_BUFFER, vbo_);
  glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 12, (void*)0);
  glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, 12, (void*)8);
  buf_.reserve(1 << 17); return true;
}
void Gfx::shutdown() { if (vbo_) glDeleteBuffers(1, &vbo_); if (vao_) glDeleteVertexArrays(1, &vao_); if (prog_) glDeleteProgram(prog_); vbo_ = vao_ = prog_ = 0; }
void Gfx::begin(int w, int h) { W = w; H = h; glViewport(0, 0, w, h); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); buf_.clear(); }
void Gfx::end() { flush(); }
void Gfx::flush() {
  if (buf_.empty()) return;
  glUseProgram(prog_); glUniform2f(uRes_, (float)W, (float)H); glBindVertexArray(vao_); glBindBuffer(GL_ARRAY_BUFFER, vbo_);
  glBufferData(GL_ARRAY_BUFFER, buf_.size() * 4, buf_.data(), GL_STREAM_DRAW); glDrawArrays(GL_TRIANGLES, 0, (int)(buf_.size() / 3)); buf_.clear();
}
void Gfx::v(float x, float y, uint32_t c) { float f; std::memcpy(&f, &c, 4); buf_.push_back(x); buf_.push_back(y); buf_.push_back(f); if (buf_.size() > 150000) flush(); }
void Gfx::rect(float x, float y, float w, float h, uint32_t c) { v(x, y, c); v(x + w, y, c); v(x, y + h, c); v(x + w, y, c); v(x + w, y + h, c); v(x, y + h, c); }
void Gfx::vgrad(float x, float y, float w, float h, uint32_t t, uint32_t b) { v(x, y, t); v(x + w, y, t); v(x, y + h, b); v(x + w, y, t); v(x + w, y + h, b); v(x, y + h, b); }
void Gfx::tri(float a, float b, float c, float d, float e, float f, uint32_t col) { v(a, b, col); v(c, d, col); v(e, f, col); }
void Gfx::circle(float cx, float cy, float r, uint32_t c, int n) { for (int i = 0; i < n; i++) { float a0 = i * 6.2831853f / n, a1 = (i + 1) * 6.2831853f / n; tri(cx, cy, cx + std::cos(a0) * r, cy + std::sin(a0) * r, cx + std::cos(a1) * r, cy + std::sin(a1) * r, c); } }
void Gfx::ring(float cx, float cy, float r, float th, uint32_t c, int n) {
  for (int i = 0; i < n; i++) { float a0 = i * 6.2831853f / n, a1 = (i + 1) * 6.2831853f / n, ri = r - th / 2, ro = r + th / 2;
    float x0 = std::cos(a0), y0 = std::sin(a0), x1 = std::cos(a1), y1 = std::sin(a1);
    tri(cx + x0 * ri, cy + y0 * ri, cx + x0 * ro, cy + y0 * ro, cx + x1 * ro, cy + y1 * ro, c); tri(cx + x0 * ri, cy + y0 * ri, cx + x1 * ro, cy + y1 * ro, cx + x1 * ri, cy + y1 * ri, c); }
}
void Gfx::line(float x1, float y1, float x2, float y2, float th, uint32_t c) {
  float dx = x2 - x1, dy = y2 - y1, l = std::sqrt(dx * dx + dy * dy); if (l < 1e-4f) return; float nx = -dy / l * th / 2, ny = dx / l * th / 2;
  tri(x1 + nx, y1 + ny, x1 - nx, y1 - ny, x2 + nx, y2 + ny, c); tri(x2 + nx, y2 + ny, x1 - nx, y1 - ny, x2 - nx, y2 - ny, c);
}
void Gfx::box(float x, float y, float w, float h, float th, uint32_t c) { rect(x, y, w, th, c); rect(x, y + h - th, w, th, c); rect(x, y + th, th, h - 2 * th, c); rect(x + w - th, y + th, th, h - 2 * th, c); }
void Gfx::rrect(float x, float y, float w, float h, float r, uint32_t c) {
  r = std::min(r, std::min(w, h) / 2); rect(x + r, y, w - 2 * r, h, c); rect(x, y + r, r, h - 2 * r, c); rect(x + w - r, y + r, r, h - 2 * r, c);
  circle(x + r, y + r, r, c, 10); circle(x + w - r, y + r, r, c, 10); circle(x + r, y + h - r, r, c, 10); circle(x + w - r, y + h - r, r, c, 10);
}
void Gfx::rotRect(float cx, float cy, float w, float h, float a, uint32_t c) {
  float co = std::cos(a), si = std::sin(a), hx = w / 2, hy = h / 2; auto P = [&](float x, float y, float& ox, float& oy) { ox = cx + x * co - y * si; oy = cy + x * si + y * co; };
  float ax, ay, bx, by, cx2, cy2, dx, dy; P(-hx, -hy, ax, ay); P(hx, -hy, bx, by); P(hx, hy, cx2, cy2); P(-hx, hy, dx, dy);
  tri(ax, ay, bx, by, dx, dy, c); tri(bx, by, cx2, cy2, dx, dy, c);
}
float Gfx::textW(const char* s, float size) const { return (float)std::strlen(s) * 6 * size / 7.f; }
void Gfx::text(const char* s, float x, float y, float size, uint32_t c, int align) {
  float u = size / 7.f, w = textW(s, size); if (align == 1) x -= w / 2; else if (align == 2) x -= w;
  for (const char* p = s; *p; p++, x += 6 * u) {
    int ch = std::toupper((unsigned char)*p); if (ch < 32 || ch > 95) ch = '?'; const uint8_t* g = F[ch - 32];
    for (int col = 0; col < 5; col++) for (int row = 0; row < 7; row++) if (g[col] >> row & 1) rect(x + col * u, y + row * u, u * 1.02f, u * 1.02f, c);
  }
}
}  // namespace cd
