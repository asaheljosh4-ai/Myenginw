// CubeDash Engine - level data + file format
#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>
namespace cd {
using Key = uint64_t;
inline Key K(int x, int y) { return ((uint64_t)(uint32_t)(x + 100000) << 32) | (uint32_t)(y + 100000); }
inline int KX(Key k) { return (int)(k >> 32) - 100000; }
inline int KY(Key k) { return (int)(k & 0xffffffffu) - 100000; }
// 'b' block 'l' slab 's' spike 'n' small spike 'd' down spike 'w' saw 'p' yellow pad 'k' pink pad
// 'o' yellow orb 'q' pink orb 'c' coin  portals: 'C' cube 'S' ship 'W' wave 'B' ball
inline float solidH(char t) { return t == 'b' ? 1.f : t == 'l' ? .5f : 0.f; }
inline bool isPortal(char t) { return t == 'C' || t == 'S' || t == 'W' || t == 'B'; }

struct Level {
  std::string name = "MY LEVEL", music;
  int diff = 1, speed = 1, bg = 1, startX = 0, startY = 0;
  float musicOff = 0;  // seconds of audio that play before x=0
  bool builtin = false;
  std::unordered_map<Key, char> t;
  char get(int x, int y) const { auto i = t.find(K(x, y)); return i == t.end() ? 0 : i->second; }
  void set(int x, int y, char c) { if (c) t[K(x, y)] = c; else t.erase(K(x, y)); }
  int maxX() const { int m = 0; for (auto& p : t) m = std::max(m, KX(p.first)); return m; }
  int coins() const { int n = 0; for (auto& p : t) n += p.second == 'c'; return n; }
  bool save(const std::string& path) const {
    std::ofstream f(path); if (!f) return false;
    f << "CDL2\nname " << name << "\ndiff " << diff << "\nspeed " << speed << "\nbg " << bg << "\nmusic " << music
      << "\nmoff " << musicOff << "\nstart " << startX << ' ' << startY << "\nn " << t.size() << "\n";
    for (auto& p : t) f << KX(p.first) << ' ' << KY(p.first) << ' ' << p.second << "\n";
    return (bool)f;
  }
  bool load(const std::string& path) {
    std::ifstream f(path); std::string line; if (!f || !std::getline(f, line) || line != "CDL2") return false;
    t.clear(); music.clear();
    while (std::getline(f, line)) {
      std::istringstream s(line); std::string k; s >> k;
      if (k == "name") { std::getline(s, name); if (!name.empty() && name[0] == ' ') name.erase(0, 1); }
      else if (k == "music") { std::getline(s, music); if (!music.empty() && music[0] == ' ') music.erase(0, 1); }
      else if (k == "diff") s >> diff; else if (k == "speed") s >> speed; else if (k == "bg") s >> bg;
      else if (k == "moff") s >> musicOff; else if (k == "start") s >> startX >> startY;
      else if (k == "n") continue;
      else { int x = 0, y = 0; char c = 0; std::istringstream r(line); if (r >> x >> y >> c) set(x, y, c); }
    }
    diff = std::clamp(diff, 0, 2); speed = std::clamp(speed, 0, 4); bg = std::clamp(bg, 0, 2);
    return true;
  }
};

// ---------- built-in levels ----------
inline Level makeDemo() {
  Level L; L.name = "STEREO START"; L.builtin = true; L.diff = 0; L.speed = 1;
  auto a = [&](char c, int x, int y) { L.set(x, y, c); };
  for (int x : {10, 16, 17, 24, 25, 26}) a('s', x, 0);
  for (int x = 30; x < 34; x++) a('b', x, 0);
  a('b', 31, 1); a('n', 35, 0); a('p', 38, 0); a('b', 42, 3); a('o', 46, 2); a('s', 50, 0); a('S', 56, 2);
  for (int x = 60; x < 100; x += 8) { a('b', x, 0); a('b', x, 1); a('b', x, 8); a('b', x, 9); a('d', x + 4, 8); }
  a('w', 70, 5); a('w', 84, 4); a('C', 104, 2); a('l', 110, 0); a('s', 113, 0); a('q', 118, 1); a('w', 124, 0); a('c', 72, 3);
  return L;
}
inline Level makeWave() {
  Level L; L.name = "WAVE RUSH"; L.builtin = true; L.diff = 1; L.speed = 1;
  for (int x = 0; x < 12; x++) if (x == 6) L.set(x, 0, 's');
  L.set(12, 2, 'W');
  for (int i = 0; i < 9; i++) {
    int x0 = 18 + i * 7, h = 3 + (i % 3), g = 2 + (i * 5) % 3;
    for (int y = 0; y < h; y++) { L.set(x0, y, 'b'); L.set(x0 + 1, y, 'b'); }
    for (int y = h + g; y <= 10; y++) { L.set(x0 + 4, y, 'b'); L.set(x0 + 5, y, 'b'); }
  }
  L.set(40, 6, 'c'); L.set(84, 4, 'C'); L.set(92, 0, 's'); L.set(98, 0, 's');
  return L;
}
inline Level makeBall() {
  Level L; L.name = "BALL FLIP"; L.builtin = true; L.diff = 2; L.speed = 1;
  L.set(8, 0, 's'); L.set(14, 1, 'B');
  for (int i = 0; i < 8; i++) { int x0 = 28 + i * 12; L.set(x0, 0, 's'); L.set(x0 + 6, 10, 'd'); if (i % 3 == 2) L.set(x0 + 3, 5, 'w'); }
  L.set(60, 5, 'c'); L.set(128, 1, 'C'); L.set(134, 0, 's');
  return L;
}
}  // namespace cd
