// CubeDash Engine - tiny batched 2D renderer (OpenGL ES 3.0) + built-in 5x7 font
#pragma once
#include <cstdint>
#include <vector>
namespace cd {
constexpr uint32_t RGBA(int r, int g, int b, int a = 255) { return (uint32_t)(r | g << 8 | b << 16 | a << 24); }
uint32_t hsl(float h, float s, float l, float a = 1.f);
uint32_t withAlpha(uint32_t c, float a);
class Gfx {
 public:
  bool init(); void shutdown();
  void begin(int w, int h); void end();
  void rect(float x, float y, float w, float h, uint32_t c);
  void vgrad(float x, float y, float w, float h, uint32_t top, uint32_t bot);
  void tri(float x1, float y1, float x2, float y2, float x3, float y3, uint32_t c);
  void circle(float cx, float cy, float r, uint32_t c, int seg = 28);
  void ring(float cx, float cy, float r, float th, uint32_t c, int seg = 28);
  void line(float x1, float y1, float x2, float y2, float th, uint32_t c);
  void box(float x, float y, float w, float h, float th, uint32_t c);   // outline
  void rrect(float x, float y, float w, float h, float r, uint32_t c);
  void rotRect(float cx, float cy, float w, float h, float rad, uint32_t c);
  void text(const char* s, float x, float y, float size, uint32_t c, int align = 0);  // 0 left 1 center 2 right, y = top
  float textW(const char* s, float size) const;
  int W = 1, H = 1;
 private:
  void v(float x, float y, uint32_t c);
  void flush();
  std::vector<float> buf_; unsigned prog_ = 0, vao_ = 0, vbo_ = 0; int uRes_ = -1;
};
}  // namespace cd
