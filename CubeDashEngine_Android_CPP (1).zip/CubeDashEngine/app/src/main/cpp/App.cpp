#include "App.h"
#include "Gfx.h"
#include "Audio.h"
#include "Sim.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <dirent.h>
#include <map>
#include <mutex>
#include <sys/stat.h>
#include <vector>
namespace cd {
enum Scr { MENU, SELECT, EDIT, PLAY, SETTINGS };
static const char* SPL[] = {"0.8X", "1X", "1.2X", "1.5X", "1.9X"};
static const char* DFN[] = {"EASY", "NORMAL", "HARD"};
static const char* BGL[] = {"BG OFF", "BG SLOW", "BG FAST"};
static const float BGS[] = {0, 2.5f, 6};
static const uint32_t DFC[3][2] = {{RGBA(79, 216, 255), RGBA(28, 143, 181)}, {RGBA(107, 220, 74), RGBA(47, 154, 28)}, {RGBA(255, 217, 59), RGBA(201, 143, 0)}};
struct PalItem { char t; const char* n; };
static const PalItem PAL[] = {{'m', "PAN"}, {'e', "ERASE"}, {'b', "BLOCK"}, {'l', "SLAB"}, {'s', "SPIKE"}, {'n', "SMALL"}, {'d', "DOWN"}, {'w', "SAW"}, {'p', "PAD"}, {'k', "PINK PAD"}, {'o', "ORB"}, {'q', "PINK ORB"},
                              {'c', "COIN"}, {'C', "CUBE"}, {'S', "SHIP"}, {'W', "WAVE"}, {'B', "BALL"}, {'T', "START"}};
struct Ptr { int id = -1; bool down = false; float x = 0, y = 0, sx = 0, sy = 0, lx = 0, ly = 0; bool moved = false, canvas = false; };
struct Particle { float x, y, vx, vy, l, m, s; uint32_t c; };
struct Entry { Level lv; std::string path; };
struct Snap { std::unordered_map<Key, char> t; int sx, sy; };

struct App {
  Platform plat; Gfx g; Audio au; bool audioOk = false, gfxOk = false;
  int W = 1280, H = 720; float u = 1, BS = 60, S = 60, Z = 1, camX = -2, camY = -2.4f, tm = 0, safeX = 20;
  Scr scr = MENU; std::string toastMsg; float toastT = 0;
  // input
  Ptr pt[6]; bool clicked = false; float clickX = 0, clickY = 0, pressX = 0, pressY = 0; bool pressDown = false; float curX = 0, curY = 0;
  // data
  std::vector<Entry> levels; int selIdx = 0; float selAnim = 0; std::map<std::string, int> best; bool practiceOpt = false, confirmDel = false;
  Level lv; std::string lvPath; bool fromEditor = false;
  float musicVol = 1, sfxVol = 1; bool showHb = false, grid = true;
  // editor
  char tool = 'b'; bool fillMode = false, panelOpen = false, previewing = false, strokeOn = false, strokeChanged = false, pinch = false, rectOn = false;
  std::vector<Snap> hist, redo; Snap strokeSnap; float palScroll = 0, pd = 1, pz = 1, awx = 0, awy = 0; int lcx = 0, lcy = 0, rsx = 0, rsy = 0, hovx = 0, hovy = 0; bool hov = false;
  // play
  Sim sim; float acc = 0, deadT = 0, wonT = 0, shake = 0, flash = 0; int attempts = 0; bool paused = false, endShown = false, playPtrDown[6] = {}, pracOn = false;
  std::vector<Particle> parts; std::vector<std::pair<float, float>> trail; int trailC = 0; float menuT = 0;
  std::mutex mu; std::string pendingMusic; bool hasPending = false;
  uint32_t dkc = 0, ltc = 0; float hue = 215;

  // ---------- util ----------
  void toast(const std::string& s) { toastMsg = s; toastT = 2.f; }
  std::string path(const char* s) const { return plat.dataDir + "/" + s; }
  float X(float x) const { return (x - camX) * S; }
  float Y(float y) const { return H - (y - camY) * S; }
  void saveCfg() { FILE* f = fopen(path("settings.cfg").c_str(), "w"); if (f) { fprintf(f, "%f %f %d %d\n", musicVol, sfxVol, (int)showHb, (int)grid); fclose(f); } }
  void loadCfg() { FILE* f = fopen(path("settings.cfg").c_str(), "r"); if (f) { int a = 0, b = 1; if (fscanf(f, "%f %f %d %d", &musicVol, &sfxVol, &a, &b) == 4) { showHb = a; grid = b; } fclose(f); } musicVol = std::clamp(musicVol, 0.f, 1.f); sfxVol = std::clamp(sfxVol, 0.f, 1.f); }
  void saveBest() { FILE* f = fopen(path("best.cfg").c_str(), "w"); if (!f) return; for (auto& b : best) fprintf(f, "%d %s\n", b.second, b.first.c_str()); fclose(f); }
  void loadBest() { FILE* f = fopen(path("best.cfg").c_str(), "r"); if (!f) return; char line[256]; while (fgets(line, 256, f)) { int p = 0; char n[200]; if (sscanf(line, "%d %199[^\n]", &p, n) == 2) best[n] = p; } fclose(f); }
  void refreshLevels() {
    levels.clear(); for (auto mk : {makeDemo, makeWave, makeBall}) levels.push_back({mk(), ""});
    std::string dir = path("levels"); if (DIR* d = opendir(dir.c_str())) { std::vector<std::string> names; while (dirent* e = readdir(d)) { std::string n = e->d_name; if (n.size() > 4 && n.substr(n.size() - 4) == ".cdl") names.push_back(n); } closedir(d); std::sort(names.begin(), names.end());
      for (auto& n : names) { Entry e; e.path = dir + "/" + n; if (e.lv.load(e.path)) levels.push_back(std::move(e)); } }
    selIdx = std::clamp(selIdx, 0, (int)levels.size() - 1);
  }
  void applyVol() { au.setMusicVolume(musicVol); au.setSfxVolume(sfxVol); }

  // ---------- lifecycle ----------
  void init() {
    mkdir(plat.dataDir.c_str(), 0775); mkdir(path("levels").c_str(), 0775); mkdir(path("music").c_str(), 0775);
    loadCfg(); loadBest(); audioOk = au.init(); applyVol(); refreshLevels();
  }
  void gfxInit(int w, int h) { gfxOk = g.init(); resize(w, h); }
  void resize(int w, int h) { W = w; H = h; u = h / 540.f; BS = h / 11.f; S = BS * Z; safeX = std::max(24.f * u, w * .035f); }

  // ---------- UI primitives ----------
  bool inside(float x, float y, float w, float h, float px, float py) const { return px >= x && px <= x + w && py >= y && py <= y + h; }
  // style: 0 glass, 1 cyan, 2 green, 3 red, 4 selected(yellow)
  bool button(float x, float y, float w, float h, const char* label, int style = 0, bool enabled = true, float ts = 15) {
    bool hot = enabled && pressDown && inside(x, y, w, h, pressX, pressY) && inside(x, y, w, h, curX, curY);
    static const uint32_t C0[] = {RGBA(40, 52, 96, 235), RGBA(91, 227, 255), RGBA(70, 220, 100), RGBA(220, 70, 70), RGBA(255, 217, 59)};
    static const uint32_t TC[] = {RGBA(238, 242, 255), RGBA(4, 34, 44), RGBA(4, 33, 10), RGBA(40, 6, 6), RGBA(50, 36, 0)};
    float k = hot ? .94f : 1.f, cx = x + w / 2, cy = y + h / 2, ww = w * k, hh = h * k;
    g.rrect(cx - ww / 2, cy - hh / 2 + 3 * u, ww, hh, 12 * u, RGBA(0, 0, 0, 90));
    g.rrect(cx - ww / 2, cy - hh / 2, ww, hh, 12 * u, enabled ? C0[style] : withAlpha(C0[style], .35f));
    if (label && *label) g.text(label, cx, cy - ts * u / 2, ts * u, enabled ? TC[style] : withAlpha(TC[style], .4f), 1);
    if (enabled && clicked && inside(x, y, w, h, clickX, clickY) && inside(x, y, w, h, pressX, pressY)) { clicked = false; au.sfx(SFX_CLICK); return true; }
    return false;
  }
  void panel(float x, float y, float w, float h) { g.rrect(x, y + 4 * u, w, h, 18 * u, RGBA(0, 0, 0, 110)); g.rrect(x, y, w, h, 18 * u, RGBA(20, 26, 52, 245)); }
  void face(float cx, float cy, float r, int d) {
    d = std::clamp(d, 0, 2); g.circle(cx, cy, r * 1.08f, RGBA(0, 0, 0)); g.circle(cx, cy, r, DFC[d][1]); g.circle(cx - r * .08f, cy - r * .1f, r * .86f, DFC[d][0]);
    for (int s = -1; s <= 1; s += 2) { g.circle(cx + s * r * .38f, cy - r * .12f, r * .24f, RGBA(255, 255, 255)); g.circle(cx + s * r * .36f, cy - r * .08f, r * .11f, RGBA(0, 0, 0));
      if (d == 2) g.line(cx + s * r * .64f, cy - r * .62f, cx + s * r * .12f, cy - r * .4f, r * .12f, RGBA(0, 0, 0)); else if (d == 0) g.line(cx + s * r * .6f, cy - r * .55f, cx + s * r * .16f, cy - r * .55f, r * .09f, RGBA(0, 0, 0)); }
    if (d == 0) { for (int i = 0; i < 8; i++) { float t = (i - 3.5f) / 3.5f; g.circle(cx + t * r * .38f, cy + r * .3f + t * t * r * .22f, r * .06f, RGBA(60, 10, 25)); } }
    else if (d == 1) g.line(cx - r * .3f, cy + r * .4f, cx + r * .3f, cy + r * .4f, r * .1f, RGBA(0, 0, 0)); else g.line(cx - r * .35f, cy + r * .5f, cx + r * .3f, cy + r * .32f, r * .1f, RGBA(0, 0, 0));
  }
  void ellipse(float cx, float cy, float rx, float ry, float th, uint32_t c, bool fill, uint32_t fc = 0) {
    const int N = 20; for (int i = 0; i < N; i++) { float a0 = i * 6.2832f / N, a1 = (i + 1) * 6.2832f / N;
      if (fill) g.tri(cx, cy, cx + std::cos(a0) * rx, cy + std::sin(a0) * ry, cx + std::cos(a1) * rx, cy + std::sin(a1) * ry, fc);
      g.line(cx + std::cos(a0) * rx, cy + std::sin(a0) * ry, cx + std::cos(a1) * rx, cy + std::sin(a1) * ry, th, c); }
  }

  // ---------- world rendering ----------
  void themeColors() { hue = std::fmod(std::fmod(215 + camX * BGS[std::clamp(lv.bg, 0, 2)], 360.f) + 360.f, 360.f); dkc = hsl(hue, .5f, .11f); ltc = hsl(hue, .85f, .72f, .4f); }
  void drawSky(float par, uint32_t col, float sz, float seed, float gy) {
    float uu = S * sz, sh = camX * S * par; int i0 = (int)std::floor(sh / uu) - 1, n = (int)std::ceil(W / uu) + 3;
    for (int i = i0; i < i0 + n; i++) { float f = std::sin(i * 12.9898f + seed) * 43758.5453f, r = std::fabs(f - std::floor(f)), hh = (r * .5f + .2f) * H * .55f; g.rect(i * uu - sh, gy - hh, uu * .85f, hh + 2, col); }
  }
  void drawBG(bool ceiling) {
    themeColors(); g.vgrad(0, 0, (float)W, (float)H, hsl(hue, .7f, .26f), hsl(hue, .75f, .5f)); float gy = Y(0);
    if (lv.bg) { drawSky(.05f * lv.bg, hsl(hue, .6f, .24f, .5f), 2.4f, 1, gy); drawSky(.1f * lv.bg, hsl(hue, .55f, .17f, .6f), 1.5f, 7, gy); }
    g.rect(0, gy, (float)W, H - gy + 20, hsl(hue, .6f, .14f)); g.rect(0, gy - 1, (float)W, 3, RGBA(255, 255, 255));
    if (ceiling) { float cy = Y(CEIL + 1); g.rect(0, 0, (float)W, cy, hsl(hue, .6f, .14f)); g.rect(0, cy - 3, (float)W, 3, RGBA(255, 255, 255)); }
  }
  void tri3(float px, float py, float s, bool down, float sc, uint32_t fill) {   // spike in a cell whose top-left is (px,py)
    float w = s * sc, x0 = px + (s - w) / 2; uint32_t wh = RGBA(255, 255, 255); float ax, ay, bx, by, cx, cy;
    if (down) { ax = px; ay = py; bx = px + s / 2; by = py + s * .92f; cx = px + s; cy = py; } else { ax = x0; ay = py + s; bx = x0 + w / 2; by = py + s - s * sc * .92f; cx = x0 + w; cy = py + s; }
    g.tri(ax, ay, bx, by, cx, cy, fill); float t = std::max(1.5f, s * .04f); g.line(ax, ay, bx, by, t, wh); g.line(bx, by, cx, cy, t, wh); g.line(cx, cy, ax, ay, t, wh);
  }
  void obj(char t, float px, float py, float s, float al, float time, bool used = false) {  // px,py = top-left of cell on screen
    uint32_t dk = withAlpha(dkc, al), wh = withAlpha(RGBA(255, 255, 255), al), lt = withAlpha(ltc, al); float c = s / 2, th = std::max(1.5f, s * .045f);
    switch (t) {
      case 'b': g.rect(px, py, s, s, dk); g.box(px, py, s, s, th, wh); g.box(px + s * .16f, py + s * .16f, s * .68f, s * .68f, std::max(1.f, th * .5f), lt); break;
      case 'l': g.rect(px, py + c, s, c, dk); g.box(px, py + c, s, c, th, wh); g.box(px + s * .12f, py + c + s * .1f, s * .76f, c - s * .2f, std::max(1.f, th * .5f), lt); break;
      case 's': tri3(px, py, s, false, 1.f, dk); break; case 'n': tri3(px, py, s, false, .5f, dk); break; case 'd': tri3(px, py, s, true, 1.f, dk); break;
      case 'w': { const int N = 16; float cx = px + c, cy = py + c, rot = time * 7; for (int i = 0; i < N; i++) { float a0 = rot + i * 3.1416f / 8, a1 = rot + (i + 1) * 3.1416f / 8, r0 = i % 2 ? s * .28f : s * .48f, r1 = (i + 1) % 2 ? s * .28f : s * .48f;
          g.tri(cx, cy, cx + std::cos(a0) * r0, cy + std::sin(a0) * r0, cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, dk); g.line(cx + std::cos(a0) * r0, cy + std::sin(a0) * r0, cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, th, wh); }
        g.ring(cx, cy, s * .12f, th, wh, 12); break; }
      case 'p': case 'k': { uint32_t co = withAlpha(t == 'p' ? RGBA(255, 217, 59) : RGBA(255, 79, 216), al); g.rect(px + s * .1f, py + s * .75f, s * .8f, s * .25f, co); g.rect(px + s * .2f, py + s * .55f, s * .6f, s * .2f, withAlpha(co, .35f)); break; }
      case 'o': case 'q': { uint32_t co = withAlpha(t == 'o' ? RGBA(255, 217, 59) : RGBA(255, 79, 216), al); float pu = std::sin(time * 5) * s * .03f; g.circle(px + c, py + c, s * .36f + pu, withAlpha(co, .53f * (used ? .3f : 1.f))); g.ring(px + c, py + c, s * .36f + pu, 3 * (s / 50), co); g.ring(px + c, py + c, s * .5f + pu, 2, withAlpha(co, .35f)); break; }
      case 'S': case 'C': case 'W': case 'B': { uint32_t co = withAlpha(t == 'S' ? RGBA(255, 79, 216) : t == 'C' ? RGBA(125, 255, 79) : t == 'W' ? RGBA(79, 216, 255) : RGBA(255, 150, 40), al); ellipse(px + c, py + c, s * .3f, s * 1.45f, 4 * (s / 50), co, true, withAlpha(co, .22f)); break; }
      case 'c': if (!used) { float sx = std::cos(time * 2.4f + px * .01f), w = std::max(2.f, std::fabs(sx) * s * .8f); g.rect(px + c - w / 2 - 2, py + c - s * .4f, w + 4, s * .8f, RGBA(0, 0, 0, (int)(255 * al))); g.rect(px + c - w / 2, py + c - s * .38f, w, s * .76f, withAlpha(RGBA(255, 190, 30), al)); g.rect(px + c - w / 3, py + c - s * .25f, w * .66f, s * .5f, withAlpha(RGBA(255, 235, 110), al)); } break;
    }
  }
  void part(float cx, float cy, float a, float ox, float oy, float w, float h, uint32_t c) { float co = std::cos(a), si = std::sin(a); g.rotRect(cx + ox * co - oy * si, cy + ox * si + oy * co, w, h, a, c); }
  void drawCube(float cx, float cy, float z, float a) {
    part(cx, cy, a, 0, 0, z + 4, z + 4, RGBA(0, 0, 0)); part(cx, cy, a, 0, 0, z, z, RGBA(125, 255, 79)); part(cx, cy, a, 0, 0, z * .66f, z * .66f, RGBA(70, 201, 31));
    part(cx, cy, a, -z * .2f, -z * .15f, z * .2f, z * .2f, RGBA(0, 0, 0)); part(cx, cy, a, z * .2f, -z * .15f, z * .2f, z * .2f, RGBA(0, 0, 0)); part(cx, cy, a, 0, z * .21f, z * .6f, z * .12f, RGBA(0, 0, 0));
  }
  void drawPlayer(float xi, float yi, float ri) {
    const Player& P = sim.P; float cx = X(xi + .5f), cy = Y(yi + .5f), a = ri * 3.14159f / 180;
    if (P.m == 'c') drawCube(cx, cy, S, a);
    else if (P.m == 's') { part(cx, cy, a, 0, S * .12f, S * 1.5f, S * .5f, RGBA(0, 0, 0)); part(cx, cy, a, 0, S * .12f, S * 1.44f, S * .42f, RGBA(42, 123, 255)); part(cx, cy, a, S * .52f, S * .12f, S * .5f, S * .26f, RGBA(120, 190, 255)); part(cx, cy, a, -S * .7f, S * .12f, S * .22f, S * .3f, RGBA(255, 160, 40)); drawCube(cx + (-std::sin(a)) * S * -.4f * -1, cy - S * .4f * std::cos(a), S * .5f, a); }
    else if (P.m == 'w') { float r = -ri * 3.14159f / 180, co = std::cos(r), si = std::sin(r), k = S * .62f; auto pp = [&](float x, float y, float& ox, float& oy) { ox = cx + (x * co - y * si) * k; oy = cy + (x * si + y * co) * k; };
      float ax, ay, bx, by, dx, dy; pp(.55f, 0, ax, ay); pp(-.45f, -.4f, bx, by); pp(-.45f, .4f, dx, dy); g.tri(ax, ay, bx, by, dx, dy, RGBA(0, 0, 0)); pp(.4f, 0, ax, ay); pp(-.3f, -.27f, bx, by); pp(-.3f, .27f, dx, dy); g.tri(ax, ay, bx, by, dx, dy, RGBA(80, 230, 255)); }
    else { g.circle(cx, cy, S * .52f, RGBA(0, 0, 0)); g.circle(cx, cy, S * .47f, RGBA(255, 140, 30)); g.circle(cx, cy, S * .3f, RGBA(120, 50, 0)); for (int i = 0; i < 4; i++) { float t = a + i * 1.5708f; g.line(cx, cy, cx + std::cos(t) * S * .46f, cy + std::sin(t) * S * .46f, S * .07f, RGBA(255, 220, 120)); } }
  }
  void spawn(float x, float y, int n, uint32_t c1, uint32_t c2, float spd, float life, float sz) {
    if (parts.size() > 400) return; for (int i = 0; i < n; i++) { float a = (rand() % 6283) / 1000.f, v = spd * (.3f + (rand() % 100) / 100.f); parts.push_back({x, y, std::cos(a) * v, std::sin(a) * v, life * (.6f + (rand() % 40) / 100.f), life, sz * (.6f + (rand() % 60) / 100.f), i & 1 ? c1 : c2}); }
  }
  void drawParts() { for (auto& p : parts) { float a = std::max(0.f, p.l / p.m), s = p.s * S; g.rect(X(p.x) - s / 2, Y(p.y) - s / 2, s, s, withAlpha(p.c, a)); } }
  void drawHb() {
    uint32_t red = RGBA(255, 59, 59); float th = 2;
    for (int cx = (int)std::floor(camX) - 1; cx <= camX + W / S + 1; cx++) for (int cy = (int)std::floor(camY) - 1; cy <= camY + H / S + 1; cy++) { char t = lv.get(cx, cy); if (!t) continue;
      auto B = [&](float a, float b, float c, float d) { g.box(X(cx + a), Y(cy + d), (c - a) * S, (d - b) * S, th, red); };
      if (t == 's') B(.42f, .1f, .58f, .5f); else if (t == 'n') B(.4f, .05f, .6f, .28f); else if (t == 'd') B(.42f, .5f, .58f, .9f); else if (t == 'b') B(0, 0, 1, 1); else if (t == 'l') B(0, 0, 1, .5f);
      else if (t == 'w') g.ring(X(cx + .5f), Y(cy + .5f), std::sqrt(.11f) * S, th, red, 16); else if (t == 'p' || t == 'k') B(0, 0, 1, .3f); }
    g.box(X(sim.P.x + .3f), Y(sim.P.y + .7f), .4f * S, .4f * S, th, red); g.box(X(sim.P.x), Y(sim.P.y + 1), S, S, th, RGBA(59, 155, 255));
  }
  void drawLevel(bool playing) {
    int x0 = (int)std::floor(camX) - 1, x1 = (int)std::ceil(camX + W / S) + 1, y0 = (int)std::floor(camY) - 2, y1 = (int)std::ceil(camY + H / S) + 2;
    for (int cx = x0; cx <= x1; cx++) for (int cy = std::max(0, y0); cy <= y1; cy++) { char t = lv.get(cx, cy); if (!t) continue; bool used = playing && sim.got.count(K(cx, cy)); obj(t, X((float)cx), Y(cy + 1.f), S, 1.f, tm, used); }
  }

  // ---------- music ----------
  void musicStartAt(float x) { if (au.loaded()) au.play(std::max(0.f, sim.timeAt(x) + lv.musicOff)); }
  void loadLevelMusic() { au.unload(); if (!lv.music.empty()) { if (!au.load(lv.music)) toast("MUSIC FILE MISSING"); } }

  // ---------- game flow ----------
  void startPlay(const Level& L, bool fromEd) {
    lv = L; fromEditor = fromEd; scr = PLAY; paused = false; endShown = false; attempts = 1; parts.clear(); trail.clear(); acc = 0; deadT = wonT = 0; pracOn = practiceOpt;
    for (auto& d : playPtrDown) d = false; sim.begin(&lv, pracOn); sim.held = false; camX = sim.P.x - W / BS * .3f; camY = -1.5f; Z = 1; S = BS; loadLevelMusic(); musicStartAt(sim.P.x);
  }
  void exitPlay() { au.stop(); scr = fromEditor ? EDIT : SELECT; if (fromEditor) { /* editor level restored from workLevel */ lv = workLevel; edCamRestore(); loadLevelMusic(); } }
  Level workLevel; float edCx = 0, edCy = 0, edZ = 1;
  void edCamSave() { edCx = camX; edCy = camY; edZ = Z; }
  void edCamRestore() { camX = edCx; camY = edCy; Z = edZ; S = BS * Z; }
  void recordBest(int pct) { if (sim.fromStart || pracOn) return; int& b = best[lv.name]; if (pct > b) { b = pct; saveBest(); } }
  void updatePlay(float dt) {
    S = BS; tm += dt;
    if (!paused) {
      acc += dt; int n = 0;
      while (acc >= DT && n++ < 40) { if (!sim.P.dead && !sim.won) { sim.step(); if (sim.ev) handleEvents(); } acc -= DT; }
      if (acc > DT) acc = 0; float al = (sim.P.dead || sim.won) ? 1.f : acc / DT; (void)al;
      if (sim.P.dead) { deadT += dt; if (deadT > .7f) { sim.respawn(); attempts++; deadT = 0; parts.clear(); trail.clear(); musicStartAt(sim.P.x); } }
      else if (sim.won) { wonT += dt; if (wonT > .8f && !endShown) { endShown = true; au.stop(); } }
      if (!sim.P.dead) { float al2 = sim.P.dead || sim.won ? 1.f : acc / DT, xi = sim.P.px + (sim.P.x - sim.P.px) * al2, yi = sim.P.py + (sim.P.y - sim.P.py) * al2;
        camX = xi - W / S * .3f; camY += (std::max(-1.5f, yi + .5f - H / S * .5f) - camY) * (1 - std::exp(-dt * 12)); }
      for (auto& p : parts) { p.vy -= 22 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.l -= dt; } parts.erase(std::remove_if(parts.begin(), parts.end(), [](const Particle& p) { return p.l <= 0; }), parts.end());
      shake = std::max(0.f, shake - dt); flash = std::max(0.f, flash - dt * 1.5f);
      if (sim.P.m == 'w' && !sim.P.dead && (++trailC & 1)) { trail.push_back({sim.P.x + .5f, sim.P.y + .5f}); if (trail.size() > 40) trail.erase(trail.begin()); } else if (sim.P.m != 'w' && !trail.empty()) trail.erase(trail.begin());
    }
  }
  void handleEvents() {
    unsigned e = sim.ev; sim.ev = 0; float x = sim.evx, y = sim.evy;
    if (e & EV_JUMP) { au.sfx(SFX_JUMP); spawn(x, y, 5, RGBA(255, 255, 255), RGBA(255, 255, 255), 3, .3f, .1f); }
    if (e & EV_COIN) { au.sfx(SFX_COIN); spawn(x, y, 14, RGBA(255, 217, 59), RGBA(255, 255, 255), 6, .5f, .12f); toast("SECRET COIN " + std::to_string(sim.gotCoins()) + "/" + std::to_string(sim.tot)); }
    if (e & (EV_PAD | EV_ORB)) { au.sfx(SFX_JUMP); spawn(x, y, 10, RGBA(255, 217, 59), RGBA(255, 79, 216), 5, .4f, .12f); }
    if (e & EV_PORTAL) { au.sfx(SFX_PORTAL); spawn(x, y, 14, RGBA(255, 79, 216), RGBA(125, 255, 79), 5, .5f, .12f); }
    if (e & EV_DIE) { au.sfx(SFX_DIE); au.stop(); shake = .3f; flash = .4f; spawn(x, y, 28, RGBA(125, 255, 79), RGBA(255, 255, 255), 9, .8f, .2f); recordBest((int)(std::min(1.f, sim.P.x / sim.endX) * 100)); }
    if (e & EV_WIN) { au.sfx(SFX_WIN); spawn(x, y, 60, RGBA(255, 217, 59), RGBA(79, 216, 255), 12, 1.6f, .2f); recordBest(100); }
  }
  void drawPlay() {
    bool ceil = sim.P.m != 'c'; float al = (sim.P.dead || sim.won) ? 1.f : acc / DT;
    if (shake > 0) { /* camera shake via offset */ camX += ((rand() % 100) / 100.f - .5f) * shake * .4f; }
    drawBG(ceil); drawLevel(true);
    if (pracOn) for (auto& c : sim.cps) { float cx = X(c.x + .5f), cy = Y(c.y + 1.4f), r = S * .2f; g.tri(cx, cy - r, cx + r, cy, cx, cy + r, RGBA(63, 232, 106)); g.tri(cx, cy - r, cx, cy + r, cx - r, cy, RGBA(63, 232, 106)); }
    float xi = sim.P.px + (sim.P.x - sim.P.px) * al, yi = sim.P.py + (sim.P.y - sim.P.py) * al, ri = sim.P.pr + (sim.P.rot - sim.P.pr) * al;
    for (size_t i = 1; i < trail.size(); i++) { float a = (float)i / trail.size(); g.line(X(trail[i - 1].first), Y(trail[i - 1].second), X(trail[i].first), Y(trail[i].second), S * .28f * a, RGBA(61, 245, 255, (int)(200 * a))); }
    if (!sim.P.dead) drawPlayer(xi, yi, ri);
    if (showHb) drawHb(); drawParts();
    if (flash > 0) g.rect(0, 0, (float)W, (float)H, RGBA(255, 255, 255, (int)(flash * 120)));
    float p = std::min(1.f, sim.P.x / sim.endX); float bw = W * .5f, bx = (W - bw) / 2, by = 14 * u;
    g.rect(bx, by, bw, 9 * u, RGBA(0, 0, 0, 150)); g.rect(bx, by, bw * p, 9 * u, pracOn ? RGBA(63, 232, 106) : RGBA(125, 255, 79));
    char buf[160]; int b = best.count(lv.name) ? best[lv.name] : 0;
    if (pracOn) snprintf(buf, sizeof buf, "%d%%  ATTEMPT %d  PRACTICE", (int)(p * 100), attempts); else if (b) snprintf(buf, sizeof buf, "%d%%  ATTEMPT %d  BEST %d%%", (int)(p * 100), attempts, b); else snprintf(buf, sizeof buf, "%d%%  ATTEMPT %d", (int)(p * 100), attempts);
    g.text(buf, W / 2.f, by + 18 * u, 14 * u, RGBA(255, 255, 255), 1);
    if (sim.tot) { snprintf(buf, sizeof buf, "COINS %d/%d", sim.gotCoins(), sim.tot); g.text(buf, safeX, 14 * u, 14 * u, RGBA(255, 217, 59)); }
    if (sim.won && !endShown) g.text("LEVEL COMPLETE", W / 2.f, H / 2.f - 20 * u, 40 * u, RGBA(255, 217, 59), 1);
    // pause button (top-right)
    float bs = 46 * u, bx2 = W - safeX - bs, by2 = 10 * u; if (button(bx2, by2, bs, bs, "", 0)) { paused = true; au.pause(true); }
    g.rect(bx2 + bs * .3f, by2 + bs * .25f, bs * .13f, bs * .5f, RGBA(255, 255, 255)); g.rect(bx2 + bs * .57f, by2 + bs * .25f, bs * .13f, bs * .5f, RGBA(255, 255, 255));
    if (paused) overlayPause(); if (endShown) overlayEnd();
  }
  void overlayPause() {
    g.rect(0, 0, (float)W, (float)H, RGBA(0, 0, 0, 170)); float pw = 360 * u, ph = 330 * u, px = (W - pw) / 2, py = (H - ph) / 2; panel(px, py, pw, ph); g.text("PAUSED", W / 2.f, py + 18 * u, 28 * u, RGBA(255, 217, 59), 1);
    if (button(px + 30 * u, py + 70 * u, pw - 60 * u, 48 * u, "RESUME", 2)) { paused = false; if (!sim.P.dead && !sim.won && au.loaded()) au.pause(false); }
    if (button(px + 30 * u, py + 128 * u, pw - 60 * u, 48 * u, pracOn ? "PRACTICE: ON" : "PRACTICE: OFF", pracOn ? 2 : 0)) { pracOn = !pracOn; practiceOpt = pracOn; sim.practice = pracOn; sim.cps.clear(); }
    if (button(px + 30 * u, py + 186 * u, pw - 60 * u, 48 * u, "RESTART", 1)) { paused = false; sim.reset(nullptr); attempts++; deadT = 0; parts.clear(); trail.clear(); musicStartAt(sim.P.x); }
    if (button(px + 30 * u, py + 244 * u, pw - 60 * u, 48 * u, "EXIT", 3)) exitPlay();
  }
  void overlayEnd() {
    g.rect(0, 0, (float)W, (float)H, RGBA(0, 0, 0, 170)); float pw = 400 * u, ph = 290 * u, px = (W - pw) / 2, py = (H - ph) / 2; panel(px, py, pw, ph);
    g.text("LEVEL COMPLETE!", W / 2.f, py + 20 * u, 28 * u, RGBA(255, 217, 59), 1); char b[80]; snprintf(b, sizeof b, "ATTEMPTS %d   COINS %d/%d", attempts, sim.gotCoins(), sim.tot); g.text(b, W / 2.f, py + 70 * u, 15 * u, RGBA(238, 242, 255), 1);
    if (button(px + 30 * u, py + 120 * u, pw - 60 * u, 52 * u, "PLAY AGAIN", 2)) { endShown = false; sim.reset(nullptr); attempts = 1; wonT = 0; parts.clear(); musicStartAt(sim.P.x); }
    if (button(px + 30 * u, py + 186 * u, pw - 60 * u, 52 * u, fromEditor ? "BACK TO EDITOR" : "LEVELS", 1)) exitPlay();
  }

  // ---------- menu ----------
  void drawMenu(float dt) {
    menuT += dt; tm += dt; S = BS; camX = menuT * 4.f; camY = -2.4f; lv.bg = 1; drawBG(false);
    float gy = Y(0), jt = std::fmod(menuT, 1.7f), jh = jt < .6f ? std::sin(jt / .6f * 3.1416f) * 2.2f : 0, rot = jt < .6f ? jt / .6f * 3.14159f : 0; // cube bounce
    obj('s', X(std::floor(camX) + 9.f) - std::fmod(camX, 1.f) * 0, gy - S, S, 1, tm);
    drawCube(W * .22f, gy - S / 2 - jh * S, S, rot); (void)rot;
    float cx = W / 2.f; g.text("CUBE DASH", cx + 4 * u, 44 * u, 74 * u, RGBA(0, 0, 0, 160), 1); g.text("CUBE DASH", cx, 40 * u, 74 * u, RGBA(125, 255, 79), 1); g.text("ENGINE", cx, 40 * u + 82 * u, 26 * u, RGBA(91, 227, 255), 1);
    float pr = 74 * u, py = H * .56f; g.circle(cx, py + 5 * u, pr, RGBA(0, 0, 0, 110)); g.circle(cx, py, pr, RGBA(40, 160, 75)); g.circle(cx, py - 4 * u, pr * .93f, RGBA(95, 240, 120));
    g.tri(cx - pr * .3f, py - pr * .45f, cx - pr * .3f, py + pr * .45f, cx + pr * .5f, py, RGBA(255, 255, 255));
    if (pressDown && inside(cx - pr, py - pr, 2 * pr, 2 * pr, pressX, pressY)) {} if (clicked && inside(cx - pr, py - pr, 2 * pr, 2 * pr, clickX, clickY) && inside(cx - pr, py - pr, 2 * pr, 2 * pr, pressX, pressY)) { clicked = false; au.sfx(SFX_CLICK); refreshLevels(); scr = SELECT; }
    if (button(cx - 330 * u, py - 28 * u, 160 * u, 56 * u, "CREATE", 1)) openEditorNew();
    if (button(cx + 170 * u, py - 28 * u, 160 * u, 56 * u, "SETTINGS", 0)) scr = SETTINGS;
    // dev badge (bottom-left)
    float bx = safeX, by = H - 70 * u; g.rrect(bx, by, 56 * u, 56 * u, 12 * u, RGBA(0, 0, 0, 140)); g.rrect(bx + 3 * u, by + 3 * u, 50 * u, 50 * u, 10 * u, RGBA(125, 255, 79)); g.rrect(bx + 11 * u, by + 11 * u, 34 * u, 34 * u, 6 * u, RGBA(46, 160, 31));
    g.rect(bx + 17 * u, by + 20 * u, 8 * u, 8 * u, RGBA(0, 0, 0)); g.rect(bx + 31 * u, by + 20 * u, 8 * u, 8 * u, RGBA(0, 0, 0)); g.rect(bx + 18 * u, by + 34 * u, 20 * u, 4 * u, RGBA(0, 0, 0));
    g.text("DEV BUILD", bx + 66 * u, by + 8 * u, 15 * u, RGBA(255, 255, 255)); g.text("CUBEDASH ENGINE V1.0  C++ + AAUDIO", bx + 66 * u, by + 32 * u, 11 * u, RGBA(200, 210, 240));
    g.text(audioOk ? "AUDIO: OK" : "AUDIO: UNAVAILABLE", W - safeX, H - 26 * u, 11 * u, audioOk ? RGBA(125, 255, 79) : RGBA(255, 120, 120), 2);
  }

  // ---------- level select ----------
  void drawSelect(float dt) {
    menuT += dt; tm += dt; S = BS; camX = menuT * 2.5f; camY = -2.4f; lv.bg = 1; drawBG(false); g.rect(0, 0, (float)W, (float)H, RGBA(8, 12, 30, 140));
    if (button(safeX, 14 * u, 90 * u, 44 * u, "BACK", 0)) scr = MENU;
    g.text("SELECT LEVEL", W / 2.f, 20 * u, 28 * u, RGBA(255, 255, 255), 1);
    if (levels.empty()) return; Entry& e = levels[selIdx]; float cw = std::min(W * .56f, 760 * u), chh = 330 * u, cx = (W - cw) / 2, cy = 84 * u + (H - 84 * u - chh) / 2 - 20 * u; if (cy < 70 * u) cy = 70 * u;
    selAnim += (0 - selAnim) * std::min(1.f, dt * 14); cx += selAnim; panel(cx, cy, cw, chh);
    face(cx + 70 * u, cy + 80 * u, 44 * u, e.lv.diff); g.text(e.lv.name.c_str(), cx + 140 * u, cy + 40 * u, 30 * u, RGBA(255, 255, 255)); char b[160];
    snprintf(b, sizeof b, "%s   SPEED %s   COINS %d   %s", DFN[std::clamp(e.lv.diff, 0, 2)], SPL[std::clamp(e.lv.speed, 0, 4)], e.lv.coins(), e.lv.builtin ? "OFFICIAL" : "CUSTOM"); g.text(b, cx + 140 * u, cy + 86 * u, 13 * u, RGBA(170, 190, 235));
    int bp = best.count(e.lv.name) ? best[e.lv.name] : 0; float bx = cx + 30 * u, bw = cw - 60 * u; g.rrect(bx, cy + 140 * u, bw, 16 * u, 8 * u, RGBA(0, 0, 0, 150)); if (bp) g.rrect(bx, cy + 140 * u, std::max(16 * u, bw * bp / 100.f), 16 * u, 8 * u, bp >= 100 ? RGBA(255, 217, 59) : RGBA(125, 255, 79));
    snprintf(b, sizeof b, "BEST %d%%%s", bp, e.lv.music.empty() ? "" : "   MUSIC"); g.text(b, bx, cy + 164 * u, 14 * u, RGBA(255, 255, 255));
    if (button(bx, cy + 200 * u, bw * .62f, 60 * u, "PLAY", 2, true, 24)) startPlay(e.lv, false);
    if (button(bx + bw * .64f, cy + 200 * u, bw * .36f, 60 * u, practiceOpt ? "PRACTICE ON" : "PRACTICE", practiceOpt ? 4 : 0, true, 13)) practiceOpt = !practiceOpt;
    if (e.lv.builtin) { if (button(bx, cy + 268 * u, bw, 44 * u, "EDIT A COPY", 1)) { Level c = e.lv; c.builtin = false; c.name += " COPY"; openEditor(c, ""); } }
    else { if (button(bx, cy + 268 * u, bw * .6f, 44 * u, "EDIT", 1)) openEditor(e.lv, e.path); if (button(bx + bw * .62f, cy + 268 * u, bw * .38f, 44 * u, confirmDel ? "SURE?" : "DELETE", 3)) { if (confirmDel) { remove(e.path.c_str()); confirmDel = false; refreshLevels(); return; } confirmDel = true; } }
    if (button(safeX, H / 2.f - 30 * u, 60 * u, 60 * u, "<", 0, selIdx > 0, 26)) { selIdx--; selAnim = -80 * u; confirmDel = false; }
    if (button(W - safeX - 60 * u, H / 2.f - 30 * u, 60 * u, 60 * u, ">", 0, selIdx + 1 < (int)levels.size(), 26)) { selIdx++; selAnim = 80 * u; confirmDel = false; }
    for (int i = 0; i < (int)levels.size(); i++) g.circle(W / 2.f + (i - (levels.size() - 1) / 2.f) * 18 * u, H - 24 * u, i == selIdx ? 6 * u : 4 * u, i == selIdx ? RGBA(255, 255, 255) : RGBA(255, 255, 255, 90));
  }
  void swipeSelect(float dx) { if (scr != SELECT) return; if (dx < -90 * u && selIdx + 1 < (int)levels.size()) { selIdx++; selAnim = 80 * u; confirmDel = false; } else if (dx > 90 * u && selIdx > 0) { selIdx--; selAnim = -80 * u; confirmDel = false; } }

  // ---------- settings ----------
  void drawSettings(float dt) {
    menuT += dt; tm += dt; S = BS; camX = menuT * 2.5f; camY = -2.4f; lv.bg = 1; drawBG(false); g.rect(0, 0, (float)W, (float)H, RGBA(8, 12, 30, 150));
    if (button(safeX, 14 * u, 90 * u, 44 * u, "BACK", 0)) { saveCfg(); scr = MENU; } g.text("SETTINGS", W / 2.f, 20 * u, 28 * u, RGBA(255, 255, 255), 1);
    float pw = std::min(W * .7f, 640 * u), px = (W - pw) / 2, py = 90 * u; panel(px, py, pw, 330 * u); char b[64];
    auto slider = [&](const char* n, float& v, float y) { g.text(n, px + 30 * u, y + 14 * u, 16 * u, RGBA(255, 255, 255)); if (button(px + pw - 300 * u, y, 56 * u, 44 * u, "-", 0)) { v = std::max(0.f, v - .1f); applyVol(); } snprintf(b, sizeof b, "%d%%", (int)std::lround(v * 100)); g.text(b, px + pw - 190 * u, y + 14 * u, 16 * u, RGBA(91, 227, 255), 1); if (button(px + pw - 86 * u, y, 56 * u, 44 * u, "+", 0)) { v = std::min(1.f, v + .1f); applyVol(); } };
    slider("MUSIC VOLUME", musicVol, py + 24 * u); slider("SFX VOLUME", sfxVol, py + 90 * u);
    if (button(px + 30 * u, py + 160 * u, pw - 60 * u, 48 * u, showHb ? "SHOW HITBOXES: ON" : "SHOW HITBOXES: OFF", showHb ? 2 : 0)) showHb = !showHb;
    if (button(px + 30 * u, py + 220 * u, pw - 60 * u, 48 * u, grid ? "EDITOR GRID: ON" : "EDITOR GRID: OFF", grid ? 2 : 0)) grid = !grid;
    g.text("DATA FOLDER: APP STORAGE / LEVELS + MUSIC", W / 2.f, py + 290 * u, 11 * u, RGBA(170, 190, 235), 1);
  }

  // ---------- editor ----------
  float topH() const { return 58 * u; } float palH() const { return 92 * u; }
  Snap snap() const { return {lv.t, lv.startX, lv.startY}; }
  void restore(const Snap& s) { lv.t = s.t; lv.startX = s.sx; lv.startY = s.sy; }
  void openEditorNew() { Level n; n.name = "LEVEL " + std::to_string(std::count_if(levels.begin(), levels.end(), [](const Entry& e) { return !e.lv.builtin; }) + 1); openEditor(n, ""); }
  void openEditor(const Level& L, const std::string& p) {
    lv = L; lvPath = p; scr = EDIT; hist.clear(); redo.clear(); panelOpen = false; previewing = false; Z = 1; S = BS; camX = -2; camY = -2.4f; tool = 'b'; sim.L = &lv; sim.sp = lv.speed; loadLevelMusic(); if (p.empty()) saveLevel();
  }
  void saveLevel() { if (lvPath.empty()) lvPath = path("levels") + "/lvl_" + std::to_string((long long)time(nullptr)) + ".cdl"; if (!lv.save(lvPath)) toast("SAVE FAILED"); }
  void doUndo() { if (hist.empty()) return; redo.push_back(snap()); restore(hist.back()); hist.pop_back(); saveLevel(); }
  void doRedo() { if (redo.empty()) return; hist.push_back(snap()); restore(redo.back()); redo.pop_back(); saveLevel(); }
  void paint(int cx, int cy) {
    if (cx < 0 || cy < 0 || cy > 60) return;
    if (tool == 'e') { if (lv.get(cx, cy)) { lv.set(cx, cy, 0); strokeChanged = true; } }
    else if (tool == 'T') { if (lv.startX != cx || lv.startY != cy) { lv.startX = cx; lv.startY = cy; strokeChanged = true; } }
    else if (tool != 'm' && lv.get(cx, cy) != tool) { lv.set(cx, cy, tool); strokeChanged = true; }
  }
  void cellAt(float px, float py, int& cx, int& cy) const { cx = (int)std::floor(px / S + camX); cy = (int)std::floor((H - py) / S + camY); }
  void paintLine(int x0, int y0, int x1, int y1) { int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0)); for (int i = 0; i <= n; i++) { float t = n ? (float)i / n : 0; paint((int)std::lround(x0 + (x1 - x0) * t), (int)std::lround(y0 + (y1 - y0) * t)); } }
  bool onBars(float x, float y) const { return y < topH() || y > H - palH() || panelOpen; }
  void edDown(Ptr& p) {
    int n = 0; for (auto& q : pt) n += q.down && q.canvas;
    if (n >= 2) {   // second finger: cancel stroke, start pinch (anchored zoom+pan)
      if (strokeOn) { restore(strokeSnap); strokeOn = false; strokeChanged = false; } rectOn = false; Ptr* a[2]; int k = 0; for (auto& q : pt) if (q.down && q.canvas && k < 2) a[k++] = &q;
      pinch = true; pd = std::max(1.f, std::hypot(a[0]->x - a[1]->x, a[0]->y - a[1]->y)); pz = Z; float mx = (a[0]->x + a[1]->x) / 2, my = (a[0]->y + a[1]->y) / 2; awx = camX + mx / S; awy = camY + (H - my) / S; return;
    }
    if (tool == 'm') return; strokeSnap = snap(); strokeOn = true; strokeChanged = false; cellAt(p.x, p.y, lcx, lcy);
    if (fillMode && tool != 'T') { rectOn = true; rsx = lcx; rsy = lcy; } else paint(lcx, lcy);
  }
  void edMove(Ptr& p, float dx, float dy) {
    if (pinch) { Ptr* a[2]; int k = 0; for (auto& q : pt) if (q.down && q.canvas && k < 2) a[k++] = &q; if (k < 2) return;
      float d = std::max(1.f, std::hypot(a[0]->x - a[1]->x, a[0]->y - a[1]->y)), mx = (a[0]->x + a[1]->x) / 2, my = (a[0]->y + a[1]->y) / 2; Z = std::clamp(pz * d / pd, .35f, 2.5f); S = BS * Z; camX = awx - mx / S; camY = std::max(-4.f, awy - (H - my) / S); return; }
    if (tool == 'm' || !strokeOn) { camX -= dx / S; camY = std::max(-4.f, camY + dy / S); return; }
    int cx, cy; cellAt(p.x, p.y, cx, cy); if (rectOn) { lcx = cx; lcy = cy; return; } if (cx != lcx || cy != lcy) { paintLine(lcx, lcy, cx, cy); lcx = cx; lcy = cy; }
  }
  void edUp(Ptr& p) {
    int n = 0; for (auto& q : pt) n += q.down && q.canvas && &q != &p; if (n < 2) pinch = false;
    if (rectOn) { int x0 = std::min(rsx, lcx), x1 = std::max(rsx, lcx), y0 = std::min(rsy, lcy), y1 = std::max(rsy, lcy); for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) paint(x, y); rectOn = false; }
    if (strokeOn && n == 0) { if (strokeChanged) { hist.push_back(strokeSnap); if (hist.size() > 60) hist.erase(hist.begin()); redo.clear(); saveLevel(); } strokeOn = false; strokeChanged = false; }
  }
  void drawEditor(float dt) {
    tm += dt; S = BS * Z; camY = std::max(-4.f, camY); camX = std::max(-6.f, camX); sim.L = &lv; sim.sp = lv.speed; bool ceil = false; drawBG(ceil);
    float gy = Y(0);
    if (grid) { uint32_t gc = RGBA(255, 255, 255, 30), gc2 = RGBA(255, 255, 255, 65); for (int x = (int)std::floor(camX); x <= camX + W / S + 1; x++) g.rect(X((float)x), 0, x % 5 == 0 ? 2.f : 1.f, (float)H, x % 5 == 0 ? gc2 : gc);
      for (int y = (int)std::floor(camY); y <= camY + H / S + 1; y++) g.rect(0, Y((float)y), (float)W, 1, gc); }
    g.rect(X(0), gy - S * 0 - S, S, S, RGBA(125, 255, 79, 40)); drawLevel(false);
    // music-length marker
    if (au.loaded()) { float endx = (au.length() - lv.musicOff) * SPD[lv.speed]; if (endx > 0) { g.rect(X(endx), 0, 3, (float)H, RGBA(255, 120, 120, 160)); g.text("MUSIC END", X(endx) + 6, gy + 8, 11 * u, RGBA(255, 160, 160)); } }
    // start pos
    { float sx = X((float)lv.startX), sy = Y(lv.startY + 1.f); g.rect(sx, sy, S, S, RGBA(125, 255, 79, 70)); g.box(sx, sy, S, S, 2, RGBA(125, 255, 79)); g.text("START", sx + S / 2, sy - 14 * u, 11 * u, RGBA(125, 255, 79), 1); }
    // ghost
    hov = false; Ptr* pp = nullptr; for (auto& q : pt) if (q.down && q.canvas) pp = &q;
    if (rectOn) { int x0 = std::min(rsx, lcx), x1 = std::max(rsx, lcx), y0 = std::min(rsy, lcy), y1 = std::max(rsy, lcy); g.rect(X((float)x0), Y(y1 + 1.f), (x1 - x0 + 1) * S, (y1 - y0 + 1) * S, tool == 'e' ? RGBA(255, 80, 80, 70) : RGBA(255, 217, 59, 60)); g.box(X((float)x0), Y(y1 + 1.f), (x1 - x0 + 1) * S, (y1 - y0 + 1) * S, 2, RGBA(255, 217, 59)); }
    if (pp && tool != 'm' && !pinch) { int cx, cy; cellAt(pp->x, pp->y, cx, cy); hovx = cx; hovy = cy; hov = true; if (!rectOn) { if (tool == 'e') g.box(X((float)cx), Y(cy + 1.f), S, S, 3, RGBA(255, 77, 77)); else if (tool != 'T') { obj(tool, X((float)cx), Y(cy + 1.f), S, .55f, tm); g.box(X((float)cx), Y(cy + 1.f), S, S, 2, RGBA(255, 217, 59)); } } }
    // top bar
    g.rect(0, 0, (float)W, topH(), RGBA(10, 14, 32, 235)); float bh = 42 * u, by = 8 * u, x = safeX;
    if (button(x, by, 70 * u, bh, "BACK", 0)) { saveLevel(); au.stop(); previewing = false; refreshLevels(); scr = SELECT; return; } x += 78 * u;
    if (button(x, by, 60 * u, bh, "UNDO", 0, !hist.empty(), 12)) doUndo(); x += 66 * u; if (button(x, by, 60 * u, bh, "REDO", 0, !redo.empty(), 12)) doRedo(); x += 66 * u;
    char b[128]; snprintf(b, sizeof b, "%s%d OBJ  ZOOM %d%%%s", hov ? ("X " + std::to_string(hovx) + " Y " + std::to_string(hovy) + "   ").c_str() : "", (int)lv.t.size(), (int)std::lround(Z * 100), fillMode ? "  FILL" : ""); g.text(b, x + 10 * u, by + 14 * u, 12 * u, RGBA(220, 230, 255));
    float rx = W - safeX; rx -= 118 * u; if (button(rx, by, 118 * u, bh, "PLAY", 2, true, 18)) { workLevel = lv; edCamSave(); au.stop(); previewing = false; startPlay(lv, true); return; }
    rx -= 100 * u; if (button(rx, by, 92 * u, bh, "MENU", panelOpen ? 4 : 0, true, 13)) panelOpen = !panelOpen;
    // palette
    float py = H - palH(); g.rect(0, py, (float)W, palH(), RGBA(10, 14, 32, 240)); float iw = 76 * u, tx = safeX - palScroll; float maxScroll = std::max(0.f, (int)(sizeof(PAL) / sizeof(PAL[0])) * iw + 2 * safeX - W);
    palScroll = std::clamp(palScroll, 0.f, maxScroll);
    for (auto& it : PAL) { float bx = tx, bw = iw - 6 * u; tx += iw; if (bx + bw < 0 || bx > W) continue; bool sel = tool == it.t; bool pressed = false;
      g.rrect(bx, py + 8 * u, bw, palH() - 16 * u, 12 * u, sel ? RGBA(91, 227, 255) : RGBA(255, 255, 255, 22));
      float s = 38 * u, ix = bx + (bw - s) / 2, iy = py + 14 * u; if (it.t == 'm') { g.line(ix + s * .5f, iy + 4, ix + s * .5f, iy + s - 4, 3, RGBA(255, 255, 255)); g.line(ix + 4, iy + s * .5f, ix + s - 4, iy + s * .5f, 3, RGBA(255, 255, 255)); }
      else if (it.t == 'e') { g.line(ix + 6, iy + 6, ix + s - 6, iy + s - 6, 5, RGBA(255, 90, 90)); g.line(ix + s - 6, iy + 6, ix + 6, iy + s - 6, 5, RGBA(255, 90, 90)); }
      else if (it.t == 'T') { g.rect(ix + 6, iy + 4, 3, s - 8, RGBA(255, 255, 255)); g.tri(ix + 9, iy + 4, ix + s - 4, iy + 12, ix + 9, iy + 20, RGBA(125, 255, 79)); }
      else { uint32_t sd = dkc, sl = ltc; dkc = RGBA(14, 20, 50); ltc = RGBA(140, 190, 255, 100); obj(it.t, ix, iy, s, 1, tm); dkc = sd; ltc = sl; }
      g.text(it.n, bx + bw / 2, py + palH() - 30 * u, 9.5f * u, sel ? RGBA(4, 34, 44) : RGBA(220, 228, 255), 1);
      if (!panelOpen && clicked && inside(bx, py, bw, palH(), clickX, clickY) && inside(bx, py, bw, palH(), pressX, pressY)) { clicked = false; tool = it.t; au.sfx(SFX_CLICK); pressed = true; } (void)pressed; }
    if (button(W - safeX - 74 * u, py - 50 * u, 74 * u, 40 * u, fillMode ? "FILL ON" : "FILL", fillMode ? 4 : 0, !panelOpen, 12)) fillMode = !fillMode;
    if (panelOpen) drawEditorPanel();
  }
  void drawEditorPanel() {
    g.rect(0, 0, (float)W, (float)H, RGBA(0, 0, 0, 120)); float pw = std::min(W * .86f, 820 * u), ph = std::min(H - 20 * u, 470 * u), px = (W - pw) / 2, py = (H - ph) / 2; panel(px, py, pw, ph); g.text("LEVEL MENU", W / 2.f, py + 14 * u, 22 * u, RGBA(255, 217, 59), 1);
    float cw = (pw - 70 * u) / 2, bh = 46 * u, x1 = px + 25 * u, x2 = x1 + cw + 20 * u, y = py + 56 * u, gap = 54 * u; char b[96];
    g.text(lv.name.c_str(), x1, y - 2 * u, 14 * u, RGBA(200, 210, 245));
    y += 22 * u;
    snprintf(b, sizeof b, "SPEED %s", SPL[lv.speed]); if (button(x1, y, cw, bh, b, 0)) { lv.speed = (lv.speed + 1) % 5; saveLevel(); }
    snprintf(b, sizeof b, "DIFFICULTY %s", DFN[lv.diff]); if (button(x2, y, cw, bh, b, 0)) { lv.diff = (lv.diff + 1) % 3; saveLevel(); } y += gap;
    if (button(x1, y, cw, bh, BGL[lv.bg], 0)) { lv.bg = (lv.bg + 1) % 3; saveLevel(); }
    if (button(x2, y, cw, bh, showHb ? "HITBOXES ON" : "HITBOXES OFF", showHb ? 2 : 0)) showHb = !showHb; y += gap;
    // music importer
    std::string mn = lv.music.empty() ? "NONE" : lv.music.substr(lv.music.find_last_of('/') + 1); if (mn.size() > 28) mn = mn.substr(0, 28);
    snprintf(b, sizeof b, "MUSIC: %s%s", mn.c_str(), au.loaded() ? "" : (lv.music.empty() ? "" : " (MISSING)")); g.text(b, x1, y + 2 * u, 13 * u, RGBA(91, 227, 255)); if (au.loaded()) { snprintf(b, sizeof b, "%.1fS   OFFSET %.2fS", au.length(), lv.musicOff); g.text(b, x2 + cw, y + 2 * u, 12 * u, RGBA(200, 210, 245), 2); } y += 22 * u;
    if (button(x1, y, cw * .5f, bh, "IMPORT", 1)) { if (plat.pickAudio) plat.pickAudio(); else toast("PICKER NOT AVAILABLE"); }
    if (button(x1 + cw * .52f, y, cw * .48f, bh, previewing ? "STOP" : "PREVIEW", previewing ? 3 : 2, au.loaded())) { if (previewing) { au.stop(); previewing = false; } else { sim.sp = lv.speed; au.play(std::max(0.f, std::max(0.f, camX) / SPD[lv.speed] + lv.musicOff)); previewing = true; } }
    if (button(x2, y, cw * .24f, bh, "-.05", 0, au.loaded())) { lv.musicOff = std::max(0.f, lv.musicOff - .05f); saveLevel(); } if (button(x2 + cw * .26f, y, cw * .24f, bh, "+.05", 0, au.loaded())) { lv.musicOff += .05f; saveLevel(); }
    if (button(x2 + cw * .52f, y, cw * .48f, bh, "REMOVE", 3, !lv.music.empty())) { au.unload(); lv.music.clear(); previewing = false; saveLevel(); } y += gap + 6 * u;
    if (button(x1, y, cw, bh, "SAVE", 2)) { saveLevel(); toast("SAVED"); } if (button(x2, y, cw, bh, "CLEAR ALL", 3)) { hist.push_back(snap()); redo.clear(); lv.t.clear(); lv.startX = lv.startY = 0; saveLevel(); } y += gap;
    if (button(x1, y, cw, bh, "RESET VIEW", 0)) { Z = 1; camX = -2; camY = -2.4f; } if (button(x2, y, cw, bh, "CLOSE", 1)) panelOpen = false;
  }

  // ---------- frame ----------
  void frame(float dt) {
    if (!gfxOk) return; dt = std::min(dt, .05f);
    { std::lock_guard<std::mutex> l(mu); if (hasPending) { hasPending = false; if (scr == EDIT) { lv.music = pendingMusic; if (au.load(pendingMusic)) { toast("MUSIC IMPORTED"); saveLevel(); } else { toast("CANNOT PLAY THIS FILE"); lv.music.clear(); } } } }
    glClearHack(); g.begin(W, H);
    switch (scr) { case MENU: drawMenu(dt); break; case SELECT: drawSelect(dt); break; case SETTINGS: drawSettings(dt); break; case EDIT: drawEditor(dt); break; case PLAY: updatePlay(dt); drawPlay(); break; }
    if (toastT > 0) { toastT -= dt; float a = std::min(1.f, toastT * 2); float w = g.textW(toastMsg.c_str(), 14 * u) + 40 * u; g.rrect((W - w) / 2, H - palH() - 74 * u + (scr == EDIT ? 0 : 60 * u), w, 36 * u, 18 * u, RGBA(0, 0, 0, (int)(210 * a))); g.text(toastMsg.c_str(), W / 2.f, H - palH() - 64 * u + (scr == EDIT ? 0 : 60 * u), 14 * u, withAlpha(RGBA(255, 255, 255), a), 1); }
    g.end(); au.update();
    clicked = false;   // a click only lives for the frame it was released in
  }
  void glClearHack();

  // ---------- input ----------
  Ptr* find(int id, bool alloc) { for (auto& p : pt) if (p.id == id) return &p; if (!alloc) return nullptr; for (auto& p : pt) if (p.id < 0) { p = Ptr(); p.id = id; return &p; } return nullptr; }
  void touch(int id, int act, float x, float y) {
    Ptr* p = find(id, act == 0); if (!p) return; curX = x; curY = y;
    if (act == 0) {
      p->down = true; p->x = p->sx = p->lx = x; p->y = p->sy = p->ly = y; p->moved = false; int n = 0; for (auto& q : pt) n += q.down; if (n == 1) { pressDown = true; pressX = x; pressY = y; }
      p->canvas = scr == EDIT && !onBars(x, y); if (p->canvas) edDown(*p);
      if (scr == PLAY && !paused && !endShown && !(x > W - safeX - 60 * u && y < 70 * u)) { playPtrDown[(p - pt)] = true; if (!sim.P.dead && !sim.won) sim.press(); }
      if (scr == EDIT && !p->canvas && y > H - palH()) { /* palette drag handled in move */ }
    } else if (act == 1) {
      float dx = x - p->lx, dy = y - p->ly; p->lx = x; p->ly = y; if (std::hypot(x - p->sx, y - p->sy) > 14 * u) p->moved = true;
      if (p->canvas) edMove(*p, dx, dy); else if (scr == EDIT && !panelOpen && p->sy > H - palH() && p->moved) palScroll -= dx;
    } else {
      float dx = x - p->sx; p->down = false; curX = x; curY = y;
      if (p->canvas) edUp(*p);
      if (scr == PLAY) { int i = (int)(p - pt); if (playPtrDown[i]) { playPtrDown[i] = false; bool any = false; for (bool d : playPtrDown) any |= d; if (!any) sim.release(); } }
      if (!p->moved) { clicked = true; clickX = x; clickY = y; } else if (scr == SELECT && std::fabs(dx) > 90 * u && std::fabs(y - p->sy) < 120 * u) swipeSelect(dx);
      int n = 0; for (auto& q : pt) n += q.down && &q != p; if (n == 0) pressDown = false; p->id = -1; p->canvas = false;
    }
  }
  bool back() {
    switch (scr) { case MENU: return false; case SELECT: scr = MENU; break; case SETTINGS: saveCfg(); scr = MENU; break;
      case EDIT: if (panelOpen) panelOpen = false; else { saveLevel(); au.stop(); previewing = false; refreshLevels(); scr = SELECT; } break;
      case PLAY: if (endShown) exitPlay(); else if (!paused) { paused = true; au.pause(true); } else { paused = false; if (!sim.P.dead && !sim.won) au.pause(false); } break; }
    return true;
  }
};

}  // namespace cd

// GL helpers kept out of the class body so App.cpp stays platform-agnostic: the clear is done by the renderer's begin() via this hook.
#if defined(CUBEDASH_NO_GL)
void cd::App::glClearHack() {}
#else
#include <GLES3/gl3.h>
void cd::App::glClearHack() { glClearColor(.04f, .06f, .12f, 1); glClear(GL_COLOR_BUFFER_BIT); }
#endif
namespace cd {
App* appNew(const Platform& p) { App* a = new App(); a->plat = p; a->init(); return a; }
void appDel(App* a) { if (!a) return; a->saveCfg(); a->au.shutdown(); a->g.shutdown(); delete a; }
void appGfxInit(App* a, int w, int h) { a->gfxInit(w, h); }
void appGfxLost(App* a) { a->gfxOk = false; }
void appResize(App* a, int w, int h) { a->resize(w, h); }
void appTouch(App* a, int id, int act, float x, float y) { a->touch(id, act, x, y); }
bool appBack(App* a) { return a->back(); }
void appFrame(App* a, float dt) { a->frame(dt); }
void appForeground(App* a, bool fg) { a->au.suspend(!fg); if (!fg && a->scr == PLAY && !a->paused) { a->paused = true; a->au.pause(true); } }
void appMusicImported(App* a, const std::string& path) { std::lock_guard<std::mutex> l(a->mu); a->pendingMusic = path; a->hasPending = true; }
}  // namespace cd
