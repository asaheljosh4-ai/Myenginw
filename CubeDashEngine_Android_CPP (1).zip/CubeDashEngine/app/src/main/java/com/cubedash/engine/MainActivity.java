package com.cubedash.engine;

import android.app.NativeActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Thin shim: everything else is C++. Needed for (1) the system file picker, (2) immersive mode. */
public class MainActivity extends NativeActivity {
    static { System.loadLibrary("cubedash"); }
    private static final int REQ_AUDIO = 4242;
    private native void nativeMusicImported(String path);

    @Override protected void onCreate(Bundle b) { super.onCreate(b); hideBars(); }
    @Override protected void onDestroy() { super.onDestroy(); }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /** Called from C++ (JNI). Opens the Android file picker for audio. */
    public void pickAudio() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("audio/*");
            startActivityForResult(i, REQ_AUDIO);
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_AUDIO || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {   // copy into app storage so native code can open it by plain file path (no content:// needed)
            try {
                String name = "music_" + System.currentTimeMillis();
                try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = c.getString(ix); }
                }
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File dir = new File(getFilesDir(), "music"); dir.mkdirs();
                File out = new File(dir, name);
                try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[1 << 16]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
                final String p = out.getAbsolutePath();
                runOnUiThread(() -> nativeMusicImported(p));
            } catch (Exception e) { android.util.Log.e("CubeDash", "music import failed", e); }
        }).start();
    }
}
