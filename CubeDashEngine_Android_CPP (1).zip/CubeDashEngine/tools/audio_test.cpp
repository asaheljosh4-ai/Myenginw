#include "../app/src/main/cpp/Audio.h"
#include <cstdio>
using namespace cd;
int main() {
  int16_t mono[4] = {0, 1000, 2000, 3000}; auto a = toStereo(mono, 4, 1, 22050, 44100); bool ok = a.size() == 16 && a[0] == a[1] && a[2] == 500 && a[14] == 3000;
  int16_t st[4] = {100, -100, 300, -300}; auto b = toStereo(st, 2, 2, 44100, 44100); ok = ok && b.size() == 4 && b[0] == 100 && b[1] == -100 && b[2] == 300 && b[3] == -300;
  int16_t six[6] = {10, 20, 30, 40, 50, 60}; auto c = toStereo(six, 1, 6, 44100, 44100); ok = ok && c.size() == 2 && c[0] == 10 && c[1] == 20;
  Audio au; ok = ok && !au.init() && !au.loaded(); au.sfx(SFX_JUMP); au.play(1); printf("audio helper tests: %s\n", ok ? "ok" : "FAIL"); return !ok;
}
