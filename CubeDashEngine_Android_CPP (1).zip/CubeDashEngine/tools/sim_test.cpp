#include "../app/src/main/cpp/Sim.h"
#include <cstdio>
using namespace cd;
int main() {
  int fails = 0; auto chk = [&](bool ok, const char* n) { printf("%-46s %s\n", n, ok ? "ok" : "FAIL"); fails += !ok; };
  { Level L = makeDemo(); Sim s; s.begin(&L, false); for (int i = 0; i < 240 * 6 && !s.P.dead; i++) s.step(); chk(s.P.dead, "cube with no input dies on first spike"); chk(s.P.x > 9 && s.P.x < 11.5f, "  death x in expected range"); }
  { Level L; L.set(5, 0, 's'); L.set(40, 3, 'c'); Sim s; s.begin(&L, false); bool j = false;
    for (int i = 0; i < 240 * 8 && !s.P.dead && !s.won; i++) { if (!j && s.P.x > 3.6f) { s.press(); j = true; } if (j && s.P.x > 4.2f) s.release(); s.step(); }
    chk(!s.P.dead && s.won, "cube jumps over a spike and finishes"); }
  { Level L; L.set(2, 0, 'W'); L.set(90, 0, 'c'); Sim s; s.begin(&L, false); for (int i = 0; i < 240 && s.P.x < 6; i++) s.step(); s.press(); float y0 = s.P.y; for (int i = 0; i < 120; i++) s.step();
    chk(s.P.m == 'w' && s.P.y > y0 + 2.f && !s.P.dead, "wave rises while held"); s.release(); for (int i = 0; i < 480; i++) s.step(); chk(!s.P.dead && s.P.y <= -.29f, "wave slides on floor when released"); }
  { Level L; L.set(2, 0, 'B'); L.set(60, 10, 'd'); Sim s; s.begin(&L, false); for (int i = 0; i < 240 && s.P.x < 5; i++) s.step(); s.press(); for (int i = 0; i < 6; i++) s.step(); s.release();
    for (int i = 0; i < 240; i++) s.step(); chk(s.P.m == 'b' && s.P.gd == -1 && s.P.y > 9.9f && !s.P.dead, "ball flips gravity, lands on ceiling"); }
  { Level L = makeWave(); Sim s; s.begin(&L, true); chk(s.endX > 100 && s.tot == 1, "wave level loads (end/coins)"); }
  { Level L = makeBall(); L.save("/tmp/t.cdl"); Level M; chk(M.load("/tmp/t.cdl") && M.t.size() == L.t.size() && M.name == L.name, "level save/load roundtrip"); }
  { Level L; L.set(30, 0, 'S'); L.startX = 40; Sim s; s.begin(&L, false); chk(s.P.m == 's' && s.fromStart, "start pos auto-picks mode from portals"); }
  printf(fails ? "\n%d FAILED\n" : "\nall passed\n", fails); return fails;
}
