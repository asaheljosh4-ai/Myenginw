# CubeDash Engine (C++ / Android)

Native C++17 port of CubeDash_Engine_v3.html: fixed-step 240 Hz physics (cube, ship, wave, ball), batched OpenGL ES 3 renderer,
touch UI, main menu, level select, full level editor and music importer. Audio is native too: AAudio output + NDK MediaCodec decoding.
No third-party libraries and nothing to download. Target: Android 8+ (Galaxy A15 = arm64-v8a).

## Build on a PC: open this folder in Android Studio and press Run.
## Build with no PC: upload the zip to a GitHub repo and add .github/workflows/build.yml (see chat instructions); GitHub builds the APK.

## Layout
- `Level.h` tile data, file format (.cdl text), built-in levels   - `Sim.h` physics/game rules (no platform code)
- `Gfx.*` GLES3 batch renderer + built-in font                    - `Audio.*` AAudio mixer, MediaCodec decoder, procedural SFX
- `App.cpp` menu / select / editor / play / settings              - `android_main.cpp` EGL, input, lifecycle, JNI
- `MainActivity.java` small shim (file picker, immersive mode)
- `tools/` desktop tests: `g++ -std=c++17 tools/sim_test.cpp -o t && ./t`

## Editor
Palette at the bottom (drag to scroll). PAN / ERASE / FILL (drag a rectangle) / blocks, hazards, pads, orbs, coins, 4 portals, START.
Two fingers = pinch-zoom + pan. MENU button: speed, difficulty, background, hitboxes, music import, preview, offset, save. Levels autosave.
